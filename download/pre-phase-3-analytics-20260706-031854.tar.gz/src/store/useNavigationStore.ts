import { create } from 'zustand';

export type Section =
  | 'home'
  | 'schedule'
  | 'rsvp'
  | 'getting-there'
  | 'story'
  | 'wishes'
  | 'qa'
  | 'moments';

interface NavigationState {
  currentSection: Section;
  drawerOpen: boolean;
  guestFirstName: string;
  guestLastName: string;
  setSection: (section: Section) => void;
  openDrawer: () => void;
  closeDrawer: () => void;
  toggleDrawer: () => void;
  setGuestName: (first: string, last: string) => void;
  getGuestFullName: () => string;
}

export const useNavigationStore = create<NavigationState>((set, get) => ({
  currentSection: 'home',
  drawerOpen: false,
  guestFirstName: '',
  guestLastName: '',
  setSection: (section) => {
    set({ currentSection: section, drawerOpen: false });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  openDrawer: () => set({ drawerOpen: true }),
  closeDrawer: () => set({ drawerOpen: false }),
  toggleDrawer: () => set((s) => ({ drawerOpen: !s.drawerOpen })),
  setGuestName: (first, last) => set({ guestFirstName: first, guestLastName: last }),
  getGuestFullName: () => {
    const { guestFirstName, guestLastName } = get();
    return [guestFirstName, guestLastName].filter(Boolean).join(' ');
  },
}));