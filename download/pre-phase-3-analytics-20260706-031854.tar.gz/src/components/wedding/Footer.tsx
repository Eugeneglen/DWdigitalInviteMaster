'use client';

import { useState } from 'react';
import { useCMSStore } from '@/store/useCMSStore';
import LegalDocumentModal from '@/components/wedding/LegalDocumentModal';
import ContactConciergeModal from '@/components/wedding/ContactConciergeModal';
import { dataProtectionDocument, termsOfServiceDocument, privacyPolicyDocument } from '@/lib/legal-content';

export default function Footer() {
  const [dataProtectionOpen, setDataProtectionOpen] = useState(false);
  const [termsOfServiceOpen, setTermsOfServiceOpen] = useState(false);
  const [privacyPolicyOpen, setPrivacyPolicyOpen] = useState(false);
  const [contactConciergeOpen, setContactConciergeOpen] = useState(false);
  const navigateToCMS = useCMSStore((s) => s.navigateToCMS);
  const authUser = useCMSStore((s) => s.authUser);

  const handleAdminAccess = () => {
    navigateToCMS(authUser ? 'dashboard' : 'login');
  };

  const footerLinkClass =
    'font-body-md text-body-md leading-body-md text-charcoal-ink/60 hover:text-cinematic-gold underline-offset-4 hover:underline transition-colors cursor-pointer';

  return (
    <>
      <footer className="w-full py-20 bg-paper-cream border-t border-champagne-silk/10 pb-32 md:pb-20">
        <div className="max-w-[1440px] mx-auto px-4 md:px-canvas-margin flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <button
              className={footerLinkClass}
              onClick={() => setContactConciergeOpen(true)}
            >
              Contact Concierge
            </button>
            <button
              className={footerLinkClass}
              onClick={() => setPrivacyPolicyOpen(true)}
            >
              Privacy Policy
            </button>
            <button
              className={footerLinkClass}
              onClick={() => setDataProtectionOpen(true)}
            >
              Data Protection
            </button>
            <button
              className={footerLinkClass}
              onClick={() => setTermsOfServiceOpen(true)}
            >
              Terms of Service
            </button>
          </div>

          <div className="flex items-center gap-6">
            <p className="font-label-sm text-label-sm leading-label-sm text-charcoal-ink/40 uppercase tracking-wider font-semibold">
              © {new Date().getFullYear()} DREAMWEAVERS DIGITAL HEIRLOOMS. All rights reserved.
            </p>
            <button
              onClick={handleAdminAccess}
              className="text-charcoal-ink/20 hover:text-charcoal-ink/50 transition-colors"
              aria-label="Admin access"
              title="Admin"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </button>
          </div>
        </div>
      </footer>

      <ContactConciergeModal
        open={contactConciergeOpen}
        onOpenChange={setContactConciergeOpen}
      />

      <LegalDocumentModal
        open={privacyPolicyOpen}
        onOpenChange={setPrivacyPolicyOpen}
        document={privacyPolicyDocument}
      />

      <LegalDocumentModal
        open={dataProtectionOpen}
        onOpenChange={setDataProtectionOpen}
        document={dataProtectionDocument}
      />

      <LegalDocumentModal
        open={termsOfServiceOpen}
        onOpenChange={setTermsOfServiceOpen}
        document={termsOfServiceDocument}
      />
    </>
  );
}