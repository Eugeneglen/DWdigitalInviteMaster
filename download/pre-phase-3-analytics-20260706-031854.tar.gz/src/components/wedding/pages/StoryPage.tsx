'use client';

import { useEffect, useRef, useState, useCallback, Suspense, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import SectionBanner from '../SectionBanner';
import { useNavigationStore } from '@/store/useNavigationStore';

const HERO_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuBZxkwieg-SjxgRYOZxJlQ1v05okmlTqzvosp-ANHaaCSQStncGv3ORTlPiE-uSYP7mQcE_wcB5Povhsm25x-eThbTLAYPt1XD-14RTSL9R5a1etGsU54CUWIwAK_4ckHoB-gD85mc-uqQwOckXVYmn0J7u0r6WkNQ2eFKKTBWBJ8yU_nirHHy8GC7vKRVnGPL6P_TymHuuKnjM3ERN9Zvho_5v7pICElncd6F8dHF-lVKppvz4kKyQe9je7CIDwOSBlcyxaGU6yY-D';

const CHAPTER1_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuAQPSczTWgJLZS_vzNbN6wuPsTVw72YpOY0ldIaXb2nEM0DjbAoH__IyOfEvlXkIvif3k6TiVwdgbsAPvCUuustCXJ5ogM8o9Mf8qfnHNM052duEcCK8KPbJVfqn8sOuo9cpUPx6XWqHpBxvEfinvKzqiiI7zy3XkVYQ7w0ElfPw1kVlE-oTiwbdti2a6Q3pUBuogYx0KyKtviULD2olRj3ZTd29I37Yi80hUtQtS9LWTuKEtFJvAKUdLp2wmjdEM8om4Ku67LEDI4t';

const PROPOSAL_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuBzzvAxvGICtmDJ5Ase_8SKR0gvAAqXe_96pLSdSUEjYyVgenag3qekxDbjpLG_SXknWJEoOXPP_XcdU4WMSloZvzj9Pn-dxdG0BBlp0lglCSzzoxLL3-2CaKrawuVRqBglPiiimHDNTlMHai2pnrr404Xg8EgQq8tdW5qRhs-bx2k6N52M80DDUW27KtR0Nc4-WkNjwCsNX8XuiyHBZTqdhpBqml323YRMNj-0offH-_Sn3jp1yxw-EAZs939pzoyGzEfpRwsteoXv';

const DEFAULT_TIDBITS = [
  {
    q: 'Who said "I love you" first?',
    a: 'It was mutual, during a particularly chaotic road trip where we got hopelessly lost but completely enjoyed the detour.',
  },
  {
    q: 'Favorite shared hobby?',
    a: 'Collecting vintage records and spending Sunday mornings listening to them while attempting to perfect our French press technique.',
  },
];

const DEFAULT_DESTINATIONS = [
  { name: 'Amalfi Coast', votes: 0 },
  { name: 'Kyoto', votes: 0 },
];

const DEFAULT_CHAPTER1 = {
  date: 'October 2018',
  title: 'The First Chapter',
  content: 'It began over accidentally swapped coffee orders at a local cafe. A simple mistake that sparked a conversation lasting hours, marking the quiet inception of a lifelong journey.',
};

const DEFAULT_PROPOSAL = {
  date: 'December 2021',
  title: 'The Proposal',
  content: 'Underneath a canopy of winter stars in the mountains, a question was asked and answered. A moment frozen in time, framed by crisp air and profound certainty.',
};

interface ContentData {
  tenant: {
    id: string;
    name: string;
    slug: string;
    coupleName1: string | null;
    coupleName2: string | null;
    eventDate: string | null;
    venue: string | null;
    settings: Record<string, Record<string, string>>;
  };
  schedule: unknown[];
  media: Record<string, { url: string; alt: string | null; caption: string | null; isCover: boolean; order: number }[]>;
  faq: unknown[];
  contentBlocks: Record<string, { id: string; title: string | null; content: string | null; imageUrl: string | null; order: number; status: string }[]>;
  features: Record<string, boolean>;
}

export default function StoryPage() {
  return (
    <Suspense>
      <StoryPageInner />
    </Suspense>
  );
}

function StoryPageInner() {
  const searchParams = useSearchParams();
  const mainRef = useRef<HTMLElement>(null);
  const [contentData, setContentData] = useState<ContentData | null>(null);

  // Compute initial name from URL params or store (runs once)
  const initialName = useMemo(() => {
    const paramFirst = searchParams.get('first');
    const paramLast = searchParams.get('last');
    const paramName = searchParams.get('name');
    if (paramFirst || paramLast) {
      return [paramFirst, paramLast].filter(Boolean).join(' ');
    } else if (paramName) {
      return paramName.trim();
    }
    return '';
  }, []);

  // Persist URL-derived name to store for cross-page use (effect, not render)
  const resolvedName = useMemo(() => initialName || useNavigationStore.getState().getGuestFullName(), [initialName]);
  useEffect(() => {
    if (initialName) {
      const parts = initialName.split(/\s+/);
      useNavigationStore.getState().setGuestName(parts[0] || '', parts.slice(1).join(' ') || '');
    }
  }, [initialName]);

  // Fetch CMS content
  useEffect(() => {
    fetch('/api/content/eleanor-james')
      .then((r) => r.json())
      .then((res) => {
        if (res.success) setContentData(res.data);
      })
      .catch(() => {});
  }, []);

  const [destinations, setDestinations] = useState(DEFAULT_DESTINATIONS);
  const [suggestions, setSuggestions] = useState<{ name: string; suggestedBy: string }[]>([]);
  const [votes, setVotes] = useState<Record<string, boolean>>({});
  const votedRef = useRef<Set<string>>(new Set());
  const [voterName, setVoterName] = useState(resolvedName);
  const [suggestion, setSuggestion] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [votingFor, setVotingFor] = useState<string | null>(null);

  const handleVote = useCallback(async (destinationName: string) => {
    if (votedRef.current.has(destinationName) || !voterName.trim() || votingFor) return;

    setVotingFor(destinationName);
    try {
      const res = await fetch('/api/story/vote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destination: destinationName, voterName: voterName.trim() }),
      });
      if (!res.ok) return;

      votedRef.current.add(destinationName);
      setVotes((prev) => ({ ...prev, [destinationName]: true }));
      setDestinations((d) =>
        d.map((dest) =>
          dest.name === destinationName
            ? { ...dest, votes: dest.votes + 1 }
            : dest
        )
      );
    } catch {
      // Silently fail
    } finally {
      setVotingFor(null);
    }
  }, [voterName, votingFor]);

  const handleSubmit = useCallback(async () => {
    if (!suggestion.trim() || submitted || !voterName.trim() || submitting) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/story/suggestion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: suggestion.trim(), suggestedBy: voterName.trim() }),
      });
      if (!res.ok) return;

      setSuggestions((prev) => [
        { name: suggestion.trim(), suggestedBy: voterName.trim() },
        ...prev,
      ]);
      setSuggestion('');
      setSubmitted(true);
    } catch {
      // Silently fail
    } finally {
      setSubmitting(false);
      setTimeout(() => setSubmitted(false), 3000);
    }
  }, [suggestion, submitted, voterName, submitting]);

  // Load vote data from backend
  useEffect(() => {
    const loadData = async () => {
      try {
        const res = await fetch('/api/story/votes');
        if (!res.ok) return;
        const data = await res.json();

        if (data.destinations) {
          // Merge backend vote counts into defaults (keep default destinations, update counts)
          const voteMap = new Map<string, number>(data.destinations.map((d: { name: string; votes: number }) => [d.name, d.votes]));
          setDestinations((prev) =>
            prev.map((d) => ({
              ...d,
              votes: voteMap.get(d.name) ?? d.votes,
            }))
          );
        }
        if (data.suggestions) {
          setSuggestions(data.suggestions);
        }
      } catch {
        // Use defaults
      }
    };
    loadData();
  }, []);

  // Scroll reveal
  useEffect(() => {
    const container = mainRef.current;
    if (!container) return;
    const els = container.querySelectorAll('.reveal');
    if (!els.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 },
    );
    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // CMS-derived values
  const storyMedia = contentData?.media?.story || [];
  const heroImg = storyMedia[0]?.url || HERO_IMG;
  const chapter1Img = contentData?.contentBlocks?.['story-chapter1']?.[0]?.imageUrl || storyMedia[1]?.url || CHAPTER1_IMG;
  const proposalImg = contentData?.contentBlocks?.['story-proposal']?.[0]?.imageUrl || storyMedia[2]?.url || PROPOSAL_IMG;

  const chapter1Block = contentData?.contentBlocks?.['story-chapter1']?.[0];
  const chapter1Title = chapter1Block?.title || DEFAULT_CHAPTER1.title;
  const chapter1Content = chapter1Block?.content || DEFAULT_CHAPTER1.content;
  const chapter1Date = DEFAULT_CHAPTER1.date;

  const proposalBlock = contentData?.contentBlocks?.['story-proposal']?.[0];
  const proposalTitle = proposalBlock?.title || DEFAULT_PROPOSAL.title;
  const proposalContent = proposalBlock?.content || DEFAULT_PROPOSAL.content;
  const proposalDate = DEFAULT_PROPOSAL.date;

  const tidbit1Block = contentData?.contentBlocks?.['story-tidbit-1']?.[0];
  const tidbit2Block = contentData?.contentBlocks?.['story-tidbit-2']?.[0];
  const tidbits = [
    {
      q: tidbit1Block?.title || DEFAULT_TIDBITS[0].q,
      a: tidbit1Block?.content || DEFAULT_TIDBITS[0].a,
    },
    {
      q: tidbit2Block?.title || DEFAULT_TIDBITS[1].q,
      a: tidbit2Block?.content || DEFAULT_TIDBITS[1].a,
    },
  ];

  return (
    <>
      <SectionBanner title="Our Story" />

      <main ref={mainRef} className="pb-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto min-h-screen pt-[20px] md:pt-[40px]">
        {/* Hero Section */}
        <section className="reveal max-w-[900px] mx-auto mb-20 flex flex-col items-center justify-center text-center">
          <p className="text-charcoal-ink max-w-2xl mx-auto opacity-80 mb-12 italic" style={{ fontSize: '18px', lineHeight: '32px' }}>
            A narrative woven through time, capturing the moments that led us here.
          </p>
          <div className="w-full max-w-4xl aspect-[16/9] inner-frame bg-surface-container-high overflow-hidden shadow-[0_20px_40px_rgba(26,26,26,0.08)]">
            <img alt="Our Story Hero" className="w-full h-full object-cover object-center" src={heroImg} />
          </div>
        </section>

        {/* Timeline */}
        <section className="reveal py-section-gap relative">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-[1px] bg-champagne-silk/50 -translate-x-1/2" />
          <div className="flex flex-col gap-section-gap">
            {/* Milestone 1 */}
            <div className="flex flex-col md:flex-row items-center justify-between w-full relative">
              <div
                className="absolute left-4 md:left-1/2 top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-cinematic-gold z-10"
                style={{ boxShadow: '0 0 10px rgba(212,175,55,0.5)' }}
              />
              <div className="w-full pl-12 md:pl-0 md:w-5/12 text-left md:text-right pr-0 md:pr-12 mb-8 md:mb-0">
                <span
                  className="text-cinematic-gold block mb-2 uppercase tracking-[0.2em]"
                  style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600 }}
                >
                  {chapter1Date}
                </span>
                <h3 className="text-charcoal-ink mb-4 italic" style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500, fontSize: '32px', lineHeight: '40px' }}>
                  {chapter1Title}
                </h3>
                <p className="text-charcoal-ink/80 italic leading-relaxed" style={{ fontSize: '16px', lineHeight: '24px' }}>
                  {chapter1Content}
                </p>
              </div>
              <div className="w-full pl-12 md:pl-0 md:w-5/12 flex justify-start">
                <div className="w-full aspect-square inner-frame bg-surface-container overflow-hidden max-w-[400px]">
                  <img alt="The First Chapter" className="w-full h-full object-cover" src={chapter1Img} />
                </div>
              </div>
            </div>

            {/* Milestone 2 */}
            <div className="flex flex-col md:flex-row-reverse items-center justify-between w-full relative">
              <div
                className="absolute left-4 md:left-1/2 top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-cinematic-gold z-10"
                style={{ boxShadow: '0 0 10px rgba(212,175,55,0.5)' }}
              />
              <div className="w-full pl-12 md:pl-0 md:w-5/12 text-left pl-0 md:pl-12 mb-8 md:mb-0">
                <span
                  className="text-cinematic-gold block mb-2 uppercase tracking-[0.2em]"
                  style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600 }}
                >
                  {proposalDate}
                </span>
                <h3 className="text-charcoal-ink mb-4 italic" style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500, fontSize: '32px', lineHeight: '40px' }}>
                  {proposalTitle}
                </h3>
                <p className="text-charcoal-ink/80 italic leading-relaxed" style={{ fontSize: '16px', lineHeight: '24px' }}>
                  {proposalContent}
                </p>
              </div>
              <div className="w-full pl-12 md:pl-0 md:w-5/12 flex justify-end">
                <div className="w-full aspect-[3/4] inner-frame bg-surface-container overflow-hidden max-w-[350px]">
                  <img alt="The Proposal" className="w-full h-full object-cover" src={proposalImg} />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Tidbits */}
        <section className="reveal py-section-gap">
          <div className="text-center mb-16">
            <h2 className="text-[32px] md:text-[48px] text-charcoal-ink mb-4" style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, lineHeight: '56px' }}>
              Tidbits
            </h2>
            <p className="text-charcoal-ink/70 italic" style={{ fontSize: '16px', lineHeight: '24px' }}>
              A few things you might not know.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {tidbits.map((item, i) => (
              <div
                key={i}
                className="p-8 border border-champagne-silk/30 bg-white/50 backdrop-blur-sm hover:shadow-[0_8px_30px_rgba(26,26,26,0.04)] transition-all duration-300"
              >
                <h4 className="font-headline-md text-[22px] text-charcoal-ink mb-3 font-semibold">
                  {item.q}
                </h4>
                <p className="text-charcoal-ink/80 italic" style={{ fontSize: '16px', lineHeight: '24px' }}>
                  {item.a}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Honeymoon Widget */}
        <section className="reveal py-section-gap">
          <div className="max-w-lg mx-auto text-center">
            {/* Decorative dots */}
            <div className="flex justify-center gap-2 mb-10">
              <span className="w-2 h-2 rounded-full bg-cinematic-gold" />
              <span className="w-2 h-2 rounded-full bg-cinematic-gold/40" />
              <span className="w-2 h-2 rounded-full bg-cinematic-gold/40" />
            </div>

            <p
              className="text-cinematic-gold uppercase mb-4"
              style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.2em', fontWeight: 600 }}
            >
              AFTER THE &lsquo;I DO&rsquo;
            </p>
            <h2
              className="text-charcoal-ink mb-3 italic"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '36px', lineHeight: '44px' }}
            >
              Where Next?
            </h2>
            <p
              className="text-charcoal-ink/50 mb-12 italic"
              style={{ fontSize: '15px', lineHeight: '22px' }}
            >
              Help us choose our honeymoon destination.
            </p>

            {/* Name field — auto-filled, underline-only input */}
            <div className="mb-10">
              <label className="block text-charcoal-ink/40 uppercase mb-3" style={{ fontSize: '11px', letterSpacing: '0.15em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}>
                YOUR NAME
              </label>
              <input
                type="text"
                value={voterName}
                onChange={(e) => setVoterName(e.target.value)}
                className="w-full bg-transparent border-0 border-b border-charcoal-ink/20 px-0 py-3 text-center font-[family-name:var(--font-playfair)] text-[16px] text-charcoal-ink placeholder:text-charcoal-ink/30 focus:ring-0 focus:border-cinematic-gold transition-colors italic outline-none"
                placeholder="Your name"
              />
            </div>

            {/* Destination vote cards */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              {destinations.map((dest) => (
                <button
                  key={dest.name}
                  type="button"
                  className={`border py-5 px-4 text-center transition-all duration-200 cursor-pointer ${
                    votes[dest.name]
                      ? 'border-cinematic-gold bg-cinematic-gold/5'
                      : 'border-charcoal-ink/10 hover:border-cinematic-gold/40'
                  } ${votingFor === dest.name ? 'opacity-60' : ''}`}
                  style={{ borderRadius: '0.25rem' }}
                  onClick={() => handleVote(dest.name)}
                  disabled={votingFor === dest.name}
                >
                  <p
                    className="text-charcoal-ink font-semibold"
                    style={{ fontFamily: "'Playfair Display', serif", fontSize: '16px', lineHeight: '22px' }}
                  >
                    {dest.name}
                  </p>
                  <p className="text-cinematic-gold mt-1.5" style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em' }}>
                    {dest.votes} {dest.votes === 1 ? 'vote' : 'votes'}
                  </p>
                </button>
              ))}
            </div>

            {/* Submitted suggestions */}
            {suggestions.length > 0 && (
              <div className="mb-6 text-left space-y-2 max-h-40 overflow-y-auto">
                {suggestions.slice(0, 5).map((s, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-charcoal-ink/5">
                    <span className="text-charcoal-ink/70 text-sm italic font-[family-name:var(--font-playfair)]">{s.name}</span>
                    <span className="text-charcoal-ink/30 text-xs">by {s.suggestedBy}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Suggestion field */}
            <div className="mb-8">
              <label className="block text-charcoal-ink/40 uppercase mb-3" style={{ fontSize: '11px', letterSpacing: '0.15em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}>
                SUGGEST A DESTINATION
              </label>
              <input
                type="text"
                value={suggestion}
                onChange={(e) => setSuggestion(e.target.value)}
                className="w-full bg-transparent border-0 border-b border-charcoal-ink/20 px-0 py-3 text-center font-[family-name:var(--font-playfair)] text-[15px] text-charcoal-ink placeholder:text-charcoal-ink/30 focus:ring-0 focus:border-cinematic-gold transition-colors italic outline-none"
                placeholder="Suggest a destination..."
              />
            </div>

            {/* Submit button */}
            <button
              type="button"
              className={`w-full py-3.5 text-[13px] font-semibold uppercase transition-all duration-300 ${
                submitted
                  ? 'bg-charcoal-ink/50 text-paper-cream/50 cursor-default'
                  : submitting
                    ? 'bg-charcoal-ink/50 text-paper-cream/50 cursor-default'
                    : 'bg-charcoal-ink text-paper-cream hover:opacity-90 cursor-pointer'
              }`}
              style={{ borderRadius: '0.25rem', letterSpacing: '0.15em' }}
              onClick={handleSubmit}
              disabled={submitting || submitted}
            >
              {submitting ? 'Submitting...' : submitted ? 'Submitted' : 'Submit'}
            </button>
          </div>
        </section>
      </main>
    </>
  );
}