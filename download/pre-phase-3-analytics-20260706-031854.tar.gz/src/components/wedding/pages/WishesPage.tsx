'use client';

import { useState, useEffect, Suspense, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import SectionBanner from '../SectionBanner';
import { useNavigationStore } from '@/store/useNavigationStore';

const CURATED_WISHES = [
  {
    type: 'image',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDQpPVCF_wPzxdxviXS1bA23h7owYEOhf8AdYzMj_9jEhL197yuR1FrPrxvhn8i0gQx_ymdPaeHz3E8o7hG3AHyFVtie3Ui4Q7e3Y7tWj8eWMC9uLbZaroGba27vEWYBtLypksUMnUEVnsJvTPDmX7a3aCGjrA47IJolG5FRrKbLKsgAciiRlNYqm7pd6PrtyvEWphw6Ckas_Jp6jkE_Fef5mfQjdt3OlTJfsQOfoWCnSC-IJteEQ0KFrwWITuhjo5_5VS7RL34j_kO',
    role: 'Maid of Honor',
    quote: '\u201CTo a love that feels like home and looks like poetry.\u201D',
    author: 'Elena Vance',
  },
  {
    type: 'text-card',
    quote: '\u201CWatching you both grow together has been the highlight of our decade. May your journey ahead be as vibrant as the silk of your traditions and as strong as the ink of your vows.\u201D',
    author: 'The Harrison Family',
  },
  {
    type: 'dark-card',
    quote: 'The art of a good marriage is in the small details. The morning coffee, the shared silence, and the unwavering support.',
    author: 'Grandmother Rose',
  },
  {
    type: 'image',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCIo9FSsp1H3KemSnsHFN9Kmplyilf5vqvEHyiSIYJ6mNQ_hui1SEYOFDn6v2uALIWIavlJXtaHgWhZv0splzeYjWkFMFD027D3ka96IvNt1dOhulLE26YW7l7o9lC4K28JT_IuNibN880fHxpwDCqPBdksFEn_7hwZwxDaI41SyFIRhOMnwfqk3VJ8L7NhuZz-4mfhWoPzjmF2azXU5Oze4LXPJZLNG4V8fSg6PF-rPn_nLB0vXqpaf1CjMyalpUE0LOvcDn7-PIjA',
    role: 'Brother & Confidant',
    quote: '\u201CMay your quiet moments be as beautiful as your loudest celebrations.\u201D',
    author: 'Marcus Thorne',
  },
  {
    type: 'minimal',
    quote: 'Distance could never diminish the joy we feel today. Sending all our blessings from across the ocean. We are there with you in spirit.',
    author: 'SOPHIE & LIAM \u00B7 COUSINS',
  },
];

interface SubmittedWish {
  id: string;
  name: string;
  relationship: string | null;
  message: string;
  createdAt: string;
}

export default function WishesPage() {
  return (
    <Suspense>
      <WishesPageInner />
    </Suspense>
  );
}

function WishesPageInner() {
  const searchParams = useSearchParams();

  // Compute initial name from URL params or store (runs once, no cascading render)
  const initialName = useMemo(() => {
    const paramFirst = searchParams.get('first');
    const paramLast = searchParams.get('last');
    const paramName = searchParams.get('name');
    if (paramFirst || paramLast) {
      return [paramFirst, paramLast].filter(Boolean).join(' ');
    } else if (paramName) {
      return paramName.trim();
    }
    return '';
  }, []);

  // Persist URL-derived name to store for cross-page use (effect, not render)
  const resolvedName = useMemo(() => initialName || useNavigationStore.getState().getGuestFullName(), [initialName]);
  useEffect(() => {
    if (initialName) {
      const parts = initialName.split(/\s+/);
      useNavigationStore.getState().setGuestName(parts[0] || '', parts.slice(1).join(' ') || '');
    }
  }, [initialName]);

  const [name, setName] = useState(resolvedName);
  const [relationship, setRelationship] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submittedWishes, setSubmittedWishes] = useState<SubmittedWish[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  // Cleanup blob URL on unmount to prevent memory leak
  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  // Load submitted wishes from backend
  useEffect(() => {
    const loadWishes = async () => {
      try {
        const res = await fetch('/api/wishes');
        if (!res.ok) return;
        const data = await res.json();
        if (data.wishes) {
          setSubmittedWishes(data.wishes);
        }
      } catch {
        // Silently fail
      }
    };
    loadWishes();
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) return;
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;
    setSubmitting(true);

    try {
      // Upload image first if selected
      let imageUrl: string | undefined;
      if (selectedFile) {
        setUploading(true);
        const fd = new FormData();
        fd.append('file', selectedFile);
        const uploadRes = await fetch('/api/upload/image', { method: 'POST', body: fd });
        if (uploadRes.ok) {
          const uploadData = await uploadRes.json();
          imageUrl = uploadData.url;
        }
        setUploading(false);
      }

      const res = await fetch('/api/wishes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), relationship: relationship.trim() || undefined, message: message.trim(), imageUrl }),
      });
      if (!res.ok) {
        setSubmitting(false);
        return;
      }

      const newWish: SubmittedWish = {
        id: 'temp-' + Date.now(),
        name: name.trim(),
        relationship: relationship.trim() || null,
        message: message.trim(),
        createdAt: new Date().toISOString(),
      };
      setSubmittedWishes((prev) => [newWish, ...prev]);
    } catch {
      setSubmitting(false);
      return;
    }

    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setRelationship('');
        setMessage('');
        removeFile();
      }, 3000);
    }, 1500);
  };

  return (
    <>
      <SectionBanner title="Wishes & Blessings" />

      <main className="pb-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto min-h-screen pt-[20px] md:pt-[40px]">
        {/* Intro */}
        <section className="max-w-[1440px] mx-auto px-8 md:px-canvas-margin mb-24 text-center">
          <span className="text-cinematic-gold uppercase mb-4 block tracking-[0.4em]" style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}>
            The Living Heirloom
          </span>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-charcoal-ink/70 leading-relaxed italic">
            A curated sanctuary of wisdom and love from those we cherish most.
          </p>
        </section>

        {/* Submitted Wishes from Backend (newest first) — 2-column gold keyline text cards */}
        {submittedWishes.length > 0 && (
          <section className="max-w-[1440px] mx-auto px-8 md:px-canvas-margin mb-32">
            <div className="text-center mb-12">
              <p
                className="text-cinematic-gold uppercase mb-2"
                style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.2em', fontWeight: 600 }}
              >
                NEWEST BLESSINGS
              </p>
            </div>
            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
              {submittedWishes.map((wish) => (
                <div key={wish.id} className="inner-frame bg-white/40 p-10 text-center flex flex-col justify-center items-center min-h-[240px]">
                  <p
                    className="text-charcoal-ink italic leading-relaxed mb-8"
                    style={{ fontFamily: "'Playfair Display', serif", fontSize: '16px', lineHeight: '26px' }}
                  >
                    &ldquo;{wish.message}&rdquo;
                  </p>
                  <div className="h-px w-12 bg-cinematic-gold/30 mx-auto mb-4" />
                  <p
                    className="uppercase tracking-[0.2em] text-charcoal-ink"
                    style={{ fontSize: '11px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                  >
                    {wish.name}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Masonry Wish Cards (curated) */}
        <section className="max-w-[1440px] mx-auto px-8 md:px-canvas-margin mb-32">
          <div className="masonry-grid">
            {CURATED_WISHES.map((wish, i) => (
              <div key={i} className="wish-card">
                {wish.type === 'image' && (
                  <>
                    <div className="inner-frame mb-8 overflow-hidden group">
                      <img
                        alt={wish.author}
                        className="w-full h-auto grayscale hover:grayscale-0 transition-all duration-1000 scale-100 group-hover:scale-105"
                        src={wish.img}
                      />
                    </div>
                    <div className="px-2">
                      <span
                        className="text-cinematic-gold mb-3 block uppercase"
                        style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                      >
                        {wish.role}
                      </span>
                      <h3 className="text-3xl italic mb-4 leading-tight">{wish.quote}</h3>
                      <p className="text-charcoal-ink/50">&mdash; {wish.author}</p>
                    </div>
                  </>
                )}

                {wish.type === 'text-card' && (
                  <div className="bg-white p-12 border border-champagne-silk/20 shadow-sm">
                    <div className="flex justify-center mb-10">
                      <span className="material-symbols-outlined text-cinematic-gold text-4xl" style={{ fontVariationSettings: "'FILL' 1" }}>favorite</span>
                    </div>
                    <p className="text-xl text-center leading-relaxed text-charcoal-ink/80 italic mb-10">
                      {wish.quote}
                    </p>
                    <div className="text-center">
                      <div className="h-px w-16 bg-cinematic-gold/30 mx-auto mb-6" />
                      <p
                        className="uppercase tracking-[0.2em] text-charcoal-ink"
                        style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                      >
                        {wish.author}
                      </p>
                    </div>
                  </div>
                )}

                {wish.type === 'dark-card' && (
                  <div className="bg-charcoal-ink text-paper-cream p-12">
                    <span className="text-7xl text-cinematic-gold/40 block mb-6" style={{ fontFamily: 'serif' }}>
                      &ldquo;
                    </span>
                    <p className="text-3xl leading-tight mb-12 italic">
                      {wish.quote}
                    </p>
                    <div className="pt-6 border-t border-paper-cream/10">
                      <p
                        className="tracking-[0.3em] uppercase"
                        style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                      >
                        {wish.author}
                      </p>
                    </div>
                  </div>
                )}

                {wish.type === 'minimal' && (
                  <div className="p-10 border-l-4 border-cinematic-gold bg-white/40">
                    <p className="text-2xl italic leading-relaxed mb-8">
                      {wish.quote}
                    </p>
                    <p
                      className="text-cinematic-gold tracking-widest"
                      style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.1em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                    >
                      {wish.author}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Contribution Form */}
        <section className="max-w-[1440px] mx-auto px-8 md:px-canvas-margin mb-32">
          <div className="max-w-md mx-auto">
            {/* Decorative dots */}
            <div className="flex justify-center gap-2 mb-10">
              <span className="w-2 h-2 rounded-full bg-cinematic-gold/40" />
              <span className="w-2 h-2 rounded-full bg-cinematic-gold/40" />
              <span className="w-2 h-2 rounded-full bg-cinematic-gold" />
            </div>

            {/* Section header */}
            <div className="text-center mb-12">
              <p
                className="text-cinematic-gold uppercase mb-4"
                style={{ fontSize: '12px', lineHeight: '16px', letterSpacing: '0.2em', fontWeight: 600 }}
              >
                YOUR TURN
              </p>
              <h2
                className="text-charcoal-ink italic mb-2"
                style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '32px', lineHeight: '40px' }}
              >
                Contribute to the Heirloom
              </h2>
              <p
                className="text-charcoal-ink/50 italic"
                style={{ fontSize: '14px', lineHeight: '20px' }}
              >
                Leave a wish, a memory, or a blessing for the couple.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Full Name — auto-filled, underline-only */}
              <div>
                <label
                  htmlFor="wishes-name"
                  className="block text-charcoal-ink/40 uppercase mb-3"
                  style={{ fontSize: '11px', letterSpacing: '0.15em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                >
                  FULL NAME
                </label>
                <input
                  id="wishes-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-transparent border-0 border-b border-charcoal-ink/20 px-0 py-3 font-[family-name:var(--font-playfair)] text-[16px] text-charcoal-ink placeholder:text-charcoal-ink/30 focus:ring-0 focus:border-cinematic-gold transition-colors italic outline-none"
                  placeholder="Your name"
                />
              </div>

              {/* Relationship — underline-only */}
              <div>
                <label
                  htmlFor="wishes-relationship"
                  className="block text-charcoal-ink/40 uppercase mb-3"
                  style={{ fontSize: '11px', letterSpacing: '0.15em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                >
                  RELATIONSHIP
                </label>
                <input
                  id="wishes-relationship"
                  type="text"
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                  className="w-full bg-transparent border-0 border-b border-charcoal-ink/20 px-0 py-3 font-[family-name:var(--font-playfair)] text-[15px] text-charcoal-ink placeholder:text-charcoal-ink/30 focus:ring-0 focus:border-cinematic-gold transition-colors italic outline-none"
                  placeholder="Friend, family, colleague..."
                />
              </div>

              {/* Your Message — underline-only textarea */}
              <div>
                <label
                  htmlFor="wishes-message"
                  className="block text-charcoal-ink/40 uppercase mb-3"
                  style={{ fontSize: '11px', letterSpacing: '0.15em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                >
                  YOUR MESSAGE
                </label>
                <textarea
                  id="wishes-message"
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-transparent border-0 border-b border-charcoal-ink/20 px-0 py-3 font-[family-name:var(--font-playfair)] text-[15px] text-charcoal-ink placeholder:text-charcoal-ink/30 focus:ring-0 focus:border-cinematic-gold transition-colors resize-none italic outline-none"
                  placeholder="Write your wish or blessing..."
                />
              </div>

              {/* Attachment — dashed upload zone */}
              <div>
                <label
                  className="block text-charcoal-ink/40 uppercase mb-3"
                  style={{ fontSize: '11px', letterSpacing: '0.15em', fontWeight: 600, fontFamily: "'Inter', sans-serif" }}
                >
                  ATTACHMENT
                </label>
                {previewUrl ? (
                  <div className="relative border border-dashed border-cinematic-gold/40 py-4 text-center">
                    <img alt="Preview" className="max-h-32 mx-auto object-contain" src={previewUrl} />
                    <button
                      type="button"
                      onClick={removeFile}
                      className="mt-2 text-[11px] text-charcoal-ink/40 hover:text-charcoal-ink/70 transition-colors underline"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center border border-dashed border-charcoal-ink/20 py-8 cursor-pointer hover:border-cinematic-gold/40 transition-colors">
                    <span className="material-symbols-outlined text-charcoal-ink/25 mb-2" style={{ fontSize: '28px' }}>cloud_upload</span>
                    <p
                      className="text-charcoal-ink/35"
                      style={{ fontSize: '14px', fontFamily: "'Playfair Display', serif" }}
                    >
                      Attach a photo or memento
                    </p>
                    <p
                      className="text-charcoal-ink/20 mt-1"
                      style={{ fontSize: '11px', fontFamily: "'Inter', sans-serif" }}
                    >
                      JPG, PNG, WebP up to 10MB
                    </p>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={handleFileSelect}
                    />
                  </label>
                )}
              </div>

              {/* Submit button — full-width black */}
              <button
                type="submit"
                disabled={submitting}
                className={`w-full py-3.5 text-[13px] font-semibold uppercase transition-all duration-300 mt-4 ${
                  submitting
                    ? 'bg-charcoal-ink/50 text-paper-cream/50 cursor-default'
                    : submitted
                      ? 'bg-charcoal-ink/50 text-paper-cream/50 cursor-default'
                      : 'bg-charcoal-ink text-paper-cream hover:opacity-90 cursor-pointer'
                }`}
                style={{ borderRadius: '0.25rem', letterSpacing: '0.15em' }}
              >
                {uploading ? 'Uploading...' : submitting ? 'Submitting...' : submitted ? 'Woven' : 'Weave into Archive'}
              </button>
            </form>
          </div>
        </section>
      </main>
    </>
  );
}