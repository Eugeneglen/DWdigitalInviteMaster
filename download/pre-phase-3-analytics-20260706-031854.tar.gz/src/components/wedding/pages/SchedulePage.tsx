'use client';

import { useCallback, useEffect, useState } from 'react';
import { useNavigationStore } from '@/store/useNavigationStore';

const CEREMONY_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuAsLNSEjy771owdkkDbKTl1nE5oEzBQFVHob_HKiQb9eJb1X7I79-CxGjCPeKwCSHhwswJRqSrt3ox_aktMQUGlyzg6Eoo5R0aH6CYxxKj5f3uZCWdaDfZEIqmxwZd5DgdvCUWZfIdnNvixcYvcspOOFnGM2ThX9BPZz-ftetacA-b6CkxEEp9BdSatnTG55-e8tZz1jlG1euZgtw17iI67tcMGtR2azzCg8GvNH-xQPfUJlAXxGC3jU9Q7dbVZPK-xnHwtTl5eRNknueI';
const CELEBRATION_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuC01POr_eFI2RUG86kAb7dHs-q12Kj6HzxEoXpnzTnJ9n_VB9_BJL6Iy8vtGixOWTn1jVNZKDjXNQkHSy9Gsa8KI5IomZe3968VCNWHhXNZ44gbgs5LCBp4_Axjbj72RJwN0BWAIEmrqH8lgR-_j2_9Ci79wI4t583OCS4YuDca-s2xldrzBhBM-KeS4GFVFDSQdzWRY-4chmwkFfFgO3g-S4VS_jae416SCd-357i_ix3m68zwnHtpBSxyXFSjZISZ_Z66Jlxj6Npv_Lo';

const BANNER_BG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuA-OyKfcsxXAmZDArHbDXl1cVCgGUG5liFPzyHdVvMG6_4jN9pNTrN9GCrkdnegli9UPJUSPs39KJRsRP7AiLem4xYS-q1ZYq1T3DAIqyvn3wAvbdkoMVkufft0SpQw4gDTPSnIml6k62lRYobUrNu70UGIILiMZQ0fAydTXXwVZ1oswQZ-mjPT8H9mDDqfhxsMSI5zla8GKz_ILXbmdRjtRUk682dPEDBD6I81DzEx7dITgjb6vxQoee5599jkYf_vCYP7npydvxqx';

const DEFAULT_VENUE_IMG = 'https://sfile.chatglm.cn/images-ppt/4adf4afbb9a2.jpg';

const DEFAULT_SCHEDULE = [
  {
    id: '1',
    time: '4:00 PM',
    title: 'The Ceremony',
    description: 'Join us as we exchange our vows and start our new chapter together.',
    tags: '["Formal Attire"]',
    order: 0,
    enabled: true,
  },
  {
    id: '2',
    time: '5:30 PM',
    title: 'Cocktail Hour',
    description: 'Enjoy signature drinks and light hors d\'oeuvres in the garden courtyard.',
    tags: '[]',
    order: 1,
    enabled: true,
  },
  {
    id: '3',
    time: '7:00 PM',
    title: 'Dinner & Dancing',
    description: 'A seated dinner followed by a night of celebration, music, and joy on the dance floor.',
    tags: '[]',
    order: 2,
    enabled: true,
  },
];

const DEFAULT_VENUE_DESCRIPTION = 'Nestled in the heart of Orchard Road, The Singapore EDITION is a luxury boutique hotel blending timeless elegance with modern sophistication. Its intimate event spaces and bespoke service make it the perfect setting for an unforgettable celebration.';

const DEFAULT_VENUE_NAME = 'The Singapore EDITION';
const DEFAULT_VENUE_FULL = 'The Singapore EDITION, 38 Cuscaden Road, Singapore 249731';
const DEFAULT_COUPLE_NAME = 'Eleanor & James';
const DEFAULT_DATE_DISPLAY = 'December 25, 2027';

interface ScheduleItem {
  id: string;
  time: string;
  title: string;
  description: string | null;
  tags: string | null;
  order: number;
  enabled: boolean;
}

interface ContentData {
  tenant: {
    id: string;
    name: string;
    slug: string;
    coupleName1: string | null;
    coupleName2: string | null;
    eventDate: string | null;
    venue: string | null;
    settings: Record<string, Record<string, string>>;
  };
  schedule: ScheduleItem[];
  media: Record<string, { url: string; alt: string | null; caption: string | null; isCover: boolean; order: number }[]>;
  faq: unknown[];
  contentBlocks: Record<string, { id: string; title: string | null; content: string | null; imageUrl: string | null; order: number; status: string }[]>;
  features: Record<string, boolean>;
}

function parseTags(tagsStr: string | null): string[] {
  if (!tagsStr) return [];
  try {
    const parsed = JSON.parse(tagsStr);
    if (Array.isArray(parsed)) return parsed;
  } catch {}
  return [];
}

export default function SchedulePage() {
  const [contentData, setContentData] = useState<ContentData | null>(null);
  const { setSection } = useNavigationStore();

  useEffect(() => {
    fetch('/api/content/eleanor-james')
      .then((r) => r.json())
      .then((res) => {
        if (res.success) setContentData(res.data);
      })
      .catch(() => {});
  }, []);

  const settings = (contentData?.tenant?.settings || {}) as Record<string, Record<string, string>>;
  const venueSettings = settings.venue || {};

  const bannerBg = contentData?.media?.hero?.[1]?.url || BANNER_BG;
  const ceremonyImg = contentData?.media?.schedule?.[0]?.url || CEREMONY_IMG;
  const celebrationImg = contentData?.media?.schedule?.[1]?.url || CELEBRATION_IMG;
  const venueImg = contentData?.media?.venue?.[0]?.url || DEFAULT_VENUE_IMG;

  const scheduleItems = (contentData?.schedule?.length ? contentData.schedule : DEFAULT_SCHEDULE) as ScheduleItem[];
  const venueDescription = contentData?.contentBlocks?.['venue-description']?.[0]?.content || DEFAULT_VENUE_DESCRIPTION;
  const venueName = venueSettings.name || DEFAULT_VENUE_NAME;
  const venueFull = contentData?.tenant?.venue || DEFAULT_VENUE_FULL;
  const coupleName = settings.hero?.coupleName1 && settings.hero?.coupleName2
    ? `${settings.hero.coupleName1} & ${settings.hero.coupleName2}`
    : DEFAULT_COUPLE_NAME;
  const dateDisplay = settings.hero?.dateDisplay || DEFAULT_DATE_DISPLAY;

  const handleAddToCalendar = useCallback(() => {
    const details = scheduleItems
      .map((item) => `${item.time} — ${item.title}`)
      .join('\n');
    const tags = scheduleItems.flatMap((item) => parseTags(item.tags));
    const attireLine = tags.length > 0 ? `\n${tags.join(', ')} requested.` : '';

    const params = new URLSearchParams({
      action: 'TEMPLATE',
      text: `${coupleName} Wedding`,
      dates: '20271225T160000/20271225T230000',
      details: `Join us for our wedding celebration!\n\n${details}${attireLine}`,
      location: venueFull,
      sprop: `name:${coupleName}`,
    });
    window.open(`https://calendar.google.com/calendar/render?${params.toString()}`, '_blank', 'noopener');
  }, [scheduleItems, coupleName, venueFull]);

  return (
    <>
      {/* Banner — matching original schedule.html */}
      <div
        className="w-full h-[360px] md:h-[420px] bg-cover bg-center mt-[54px] md:mt-[64px] relative z-40 border-b border-champagne-silk/20 flex items-center justify-center"
        style={{ backgroundImage: `url('${bannerBg}')` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-paper-cream/30 via-paper-cream/10 to-paper-cream/60" />
        <div className="relative z-10 text-center px-6">
          <h1 className="font-display-hero text-[44px] md:text-[72px] leading-[1.05] text-charcoal-ink tracking-tight font-bold drop-shadow-sm">The Schedule</h1>
        </div>
      </div>

      <main className="pb-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto min-h-screen pt-[20px] md:pt-[40px]">
        {/* Intro Images — original: stagger-1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16 stagger-1">
          <div className="aspect-[4/5] overflow-hidden rounded-lg">
            <img alt="The Ceremony" className="w-full h-full object-cover" src={ceremonyImg} />
          </div>
          <div className="aspect-[4/5] overflow-hidden rounded-lg">
            <img alt="The Celebration" className="w-full h-full object-cover" src={celebrationImg} />
          </div>
        </div>

        {/* Date line — original: stagger-1, font-body-lg = 18px/32px/400 */}
        <section className="mb-24 text-center stagger-1">
          <p className="text-body-lg leading-body-lg text-charcoal-ink/70 max-w-2xl mx-auto italic">Saturday, {dateDisplay}</p>
        </section>

        {/* Timeline — original: stagger-3 on wrapper */}
        <section className="max-w-4xl mx-auto">
          <div className="mb-24 stagger-3">
            {/* Sticky heading — original: font-display-hero text-headline-md(32px/40px/500) md:text-headline-lg(48px/56px/600) */}
            <div className="sticky top-24 md:top-40 bg-paper-cream/90 backdrop-blur-sm z-30 py-4 mb-12 border-b border-champagne-silk/30 flex items-baseline gap-4">
              <h2 className="font-display-hero text-headline-md leading-headline-md font-medium md:text-headline-lg md:leading-headline-lg md:font-semibold text-charcoal-ink">The Celebration</h2>
              {/* Original: font-utility-mono = 14px/20px/500 */}
              <span className="font-utility-mono text-utility-mono leading-utility-mono font-medium text-charcoal-ink/60 italic tracking-wider uppercase">{dateDisplay}</span>
            </div>

            <div className="relative border-l border-champagne-silk/40 ml-4 md:ml-8 pl-8 md:pl-16 flex flex-col gap-16">
              {scheduleItems.map((item) => {
                const tags = parseTags(item.tags);
                return (
                  <div key={item.id} className="relative group">
                    <div className="absolute -left-[calc(2px+7px)] md:-left-[calc(2px+7px)] top-2.5 w-[6px] h-[6px] rounded-full bg-cinematic-gold" />
                    <div className="flex flex-col gap-2">
                      <span className="inline-block self-start px-2.5 py-1 rounded bg-champagne-silk/40 text-[11px] font-medium uppercase tracking-widest text-charcoal-ink/70 mb-1">{item.time}</span>
                      <h3 className="font-display-hero text-headline-md-mobile md:text-headline-lg-mobile md:leading-headline-lg-mobile md:font-semibold text-charcoal-ink">{item.title}</h3>
                      {item.description && (
                        <p className="text-body-md leading-body-md text-charcoal-ink/70 leading-relaxed">{item.description}</p>
                      )}
                      {tags.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {tags.map((tag) => (
                            <span key={tag} className="inline-flex items-center px-3 py-1 rounded-full bg-champagne-silk/30 text-charcoal-ink text-[10px] tracking-widest uppercase font-bold">{tag}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Action Buttons — flat bordered style matching reference design */}
        <section className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-24 stagger-4">
          <button
            type="button"
            onClick={handleAddToCalendar}
            className="w-full sm:w-auto border border-charcoal-ink/15 bg-white rounded px-8 py-3 text-[13px] font-medium uppercase tracking-[0.08em] text-charcoal-ink hover:border-cinematic-gold hover:text-cinematic-gold transition-colors duration-300"
          >
            Add to Calendar
          </button>
          <button
            type="button"
            onClick={() => setSection('getting-there')}
            className="w-full sm:w-auto border border-charcoal-ink/15 bg-white rounded px-8 py-3 text-[13px] font-medium uppercase tracking-[0.08em] text-charcoal-ink hover:border-cinematic-gold hover:text-cinematic-gold transition-colors duration-300"
          >
            Directions
          </button>
        </section>

        {/* Wedding Venue Section */}
        <section className="stagger-4 mb-24 flex flex-col md:flex-row gap-8 md:gap-12 items-center">
          <div className="w-full md:w-1/2 shrink-0">
            <div className="aspect-[4/3] overflow-hidden rounded border border-cinematic-gold/30">
              <img
                alt={`${venueName} — Wedding Venue`}
                className="w-full h-full object-cover"
                src={venueImg}
              />
            </div>
          </div>
          <div className="w-full md:w-1/2 flex flex-col gap-4">
            <span className="text-label-sm leading-label-sm text-cinematic-gold tracking-[0.2em] uppercase font-semibold">Wedding Venue</span>
            <h3 className="font-display-hero text-headline-lg-mobile leading-headline-lg-mobile md:text-headline-md md:leading-headline-md font-semibold text-charcoal-ink">{venueName}</h3>
            <p className="text-body-md leading-body-md text-charcoal-ink/70 leading-relaxed">
              {venueDescription}
            </p>
          </div>
        </section>
      </main>
    </>
  );
}