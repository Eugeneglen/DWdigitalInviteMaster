'use client';

import { useState, useEffect } from 'react';
import { useNavigationStore } from '@/store/useNavigationStore';
import BokehOrbs from '../BokehOrbs';

const HERO_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuBeAe38AA5-0h4B5MmgQCqv54oQXyPMGznDKaw2sJI_FnTbB_yXXWOpirFlFycj_2VI02IVLouUTt86Y1J7Ls-bRsMOHPAcfSqruVoh87sfhw3vi2Z6t1C7ogCLtkvF6QbJkwuV0av8pXTrUeAAi6ymnZpvyOr8qVjTNNorAOmqRrW_fohX_xlkscmBh39K4Wtvs6TH0Nvb_X3LQQRD9W_sySN_iWbWw9O0au8u1jO-hSekE9pSGNo5zsTz3o9PWy5xbzc6lq3knkIy';

const TEA_IMG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuA6SiJt49KQCmMAhF-X_tmX1Y1NKhTieT6ApO53PD9gYuvLO0e78WTxzg8BV7Wnhe6oJ6sG4SwJ4U-nH2m33dv7I89IhLgrHDkabts7ws-QwPlv-ycUzhyuBN0c04ka2inAyysumlM1w-sR8stBZ51HJOGZkQO6cAtfrn9RXWZRFlHJlUp8Jqzi-nBu3xGs57xm7L2Le06Put3xBDMAe39zkMMsdcuUkbeyw5c4Q6VxvXkSmMbcpLM-HJK1iMgYVLkn2kzqUPEALYpH';

const WEDDING_DATE = new Date('2027-12-25T16:00:00').getTime();

const BANNER_BG =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuA-OyKfcsxXAmZDArHbDXl1cVCgGUG5liFPzyHdVvMG6_4jN9pNTrN9GCrkdnegli9UPJUSPs39KJRsRP7AiLem4xYS-q1ZYq1T3DAIqyvn3wAvbdkoMVkufft0SpQw4gDTPSnIml6k62lRYobUrNu70UGIILiMZQ0fAydTXXwVZ1oswQZ-mjPT8H9mDDqfhxsMSI5zla8GKz_ILXbmdRjtRUk682dPEDBD6I81DzEx7dITgjb6vxQoee5599jkYf_vCYP7npydvxqx';

interface ContentData {
  tenant: {
    id: string;
    name: string;
    slug: string;
    coupleName1: string | null;
    coupleName2: string | null;
    eventDate: string | null;
    venue: string | null;
    settings: Record<string, Record<string, string>>;
  };
  media: Record<string, { url: string; alt: string | null; caption: string | null; isCover: boolean; order: number }[]>;
  schedule: unknown[];
  faq: unknown[];
  contentBlocks: Record<string, unknown[]>;
  features: Record<string, boolean>;
}

function useCountdown(targetDate: number) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, mins: 0, secs: 0 });

  useEffect(() => {
    const calc = () => {
      const now = Date.now();
      const diff = Math.max(0, targetDate - now);
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        mins: Math.floor((diff / (1000 * 60)) % 60),
        secs: Math.floor((diff / 1000) % 60),
      });
    };
    calc();
    const interval = setInterval(calc, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  return timeLeft;
}

export default function HomePage() {
  const [contentData, setContentData] = useState<ContentData | null>(null);
  const { setSection } = useNavigationStore();
  const [showFab, setShowFab] = useState(false);

  useEffect(() => {
    fetch('/api/content/eleanor-james')
      .then((r) => r.json())
      .then((res) => {
        if (res.success) setContentData(res.data);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const onScroll = () => setShowFab(window.scrollY > 300);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Dynamic values from CMS or fallback to defaults
  const settings = (contentData?.tenant?.settings || {}) as Record<string, Record<string, string>>;
  const heroSettings = settings.hero || {};

  const bannerBg = contentData?.media?.hero?.[1]?.url || BANNER_BG;
  const heroImg = contentData?.media?.hero?.[0]?.url || HERO_IMG;
  const teaImg = contentData?.media?.['tea-ceremony']?.[0]?.url || TEA_IMG;

  const weddingDate = contentData?.tenant?.eventDate
    ? new Date(contentData.tenant.eventDate).getTime()
    : WEDDING_DATE;

  const coupleName =
    heroSettings.coupleName1 && heroSettings.coupleName2
      ? `${heroSettings.coupleName1} & ${heroSettings.coupleName2}`
      : 'Eleanor & James';

  const dateDisplay = heroSettings.dateDisplay || 'December 25, 2027';

  const tagline = heroSettings.tagline || 'Together with their families, request the pleasure of your company';

  const teaCeremonyTitle = heroSettings.teaCeremonyTitle || 'The Tea Ceremony';
  const teaCeremonySubtitle = heroSettings.teaCeremonySubtitle || 'The Tradition';

  const narrativeTitle = heroSettings.narrativeTitle || 'Our Story Begins Here';
  const narrativeSubtitle = heroSettings.narrativeSubtitle || 'The Prelude';
  const narrativeContent =
    heroSettings.narrativeContent ||
    'Every great romance is a narrative woven over time. Ours began with a serendipitous meeting and has evolved into a tapestry of shared adventures, quiet moments, and a profound commitment to one another.';

  const countdown = useCountdown(weddingDate);

  return (
    <>
      {/* ===== TOP BANNER — "Eleanor & James" ===== */}
      {/* Original: <div class="w-full h-[360px] md:h-[420px] bg-cover bg-center mt-[54px] md:mt-[64px] relative z-40 border-b border-champagne-silk/20 flex items-center justify-center" style="background-image: url('...')"> */}
      {/* Original:   <div class="absolute inset-0 bg-gradient-to-b from-paper-cream/30 via-paper-cream/10 to-paper-cream/60"></div> */}
      {/* Original:   <div class="relative z-10 text-center px-6"> */}
      {/* Original:     <h1 class="font-display-hero text-[44px] md:text-[72px] leading-[1.05] text-charcoal-ink tracking-tight font-bold drop-shadow-sm">Eleanor &amp; James</h1> */}
      <div
        className="w-full h-[360px] md:h-[420px] bg-cover bg-center mt-[54px] md:mt-[64px] relative z-40 border-b border-champagne-silk/20 flex items-center justify-center"
        style={{ backgroundImage: `url('${bannerBg}')` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-paper-cream/30 via-paper-cream/10 to-paper-cream/60" />
        <div className="relative z-10 text-center px-6">
          <h1 className="font-display-hero text-[44px] md:text-[72px] leading-[1.05] text-charcoal-ink tracking-tight font-bold drop-shadow-sm">
            {coupleName.replace(/&/g, '&amp;')}
          </h1>
        </div>
      </div>

      {/* ===== MAIN CONTENT ===== */}
      {/* Original: <main class="pb-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto min-h-screen pt-[20px] md:pt-[40px]"> */}
      <main className="pb-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto min-h-screen pt-[20px] md:pt-[40px]">
        {/* ===== HERO SECTION ===== */}
        {/* Original: <section class="relative h-[795px] md:h-screen w-full flex flex-col justify-end overflow-hidden"> */}
        <section className="relative h-[795px] md:h-screen w-full flex flex-col justify-end overflow-hidden">
          <BokehOrbs />
          {/* Background Image — full bleed, no crop */}
          <div className="absolute inset-0 z-0">
            <img
              alt="Hero Wedding Portrait"
              className="w-full h-full object-cover object-center"
              src={heroImg}
            />

          </div>

          {/* Content Overlay */}
          {/* Original: <div class="relative z-10 w-full px-8 md:px-24 pb-20 md:pb-32 flex flex-col items-center text-center"> */}
          <div className="relative z-10 w-full px-8 md:px-24 pb-20 md:pb-32 flex flex-col items-center text-center">
            {/* Master Date Badge */}
            {/* Original: <div class="animate-fade-in delay-100 mb-8 inline-flex items-center justify-center border border-champagne-silk px-6 py-2 rounded-full bg-paper-cream/10 backdrop-blur-sm"> */}
            <div className="animate-fade-in delay-100 mb-8 inline-flex items-center justify-center border border-champagne-silk px-6 py-2 rounded-full bg-paper-cream/10 backdrop-blur-sm">
              <span className="font-label-sm text-label-sm leading-label-sm text-paper-cream tracking-[0.2em] uppercase font-semibold">
                {dateDisplay}
              </span>
            </div>

            {/* Description */}
            <p className="animate-slide-up delay-300 font-body-md text-body-md leading-body-md text-paper-cream/80 max-w-md mx-auto mb-12 italic">
              {tagline}
            </p>

            {/* Countdown Component — individual dark rounded boxes */}
            <div className="animate-slide-up delay-400 grid grid-cols-4 gap-3 md:gap-4 w-full max-w-md mx-auto">
              {[
                { value: countdown.days, label: 'DAYS' },
                { value: countdown.hours, label: 'HOURS' },
                { value: countdown.mins, label: 'MINS' },
                { value: countdown.secs, label: 'SECS' },
              ].map((item) => (
                <div key={item.label} className="inner-frame flex flex-col items-center justify-center bg-paper-cream/10 backdrop-blur-sm py-4 md:py-5">
                  <span className="font-display-hero text-3xl md:text-4xl font-bold text-paper-cream leading-none">
                    {String(item.value).padStart(2, '0')}
                  </span>
                  <span className="font-label-sm text-[9px] md:text-[10px] text-cinematic-gold tracking-widest uppercase mt-2 font-semibold">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Scroll Indicator */}
          {/* Original: <div class="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 animate-fade-in delay-400 flex flex-col items-center opacity-70"> */}
          {/* Original:   <span class="font-label-sm text-[10px] text-paper-cream tracking-widest mb-2 uppercase font-semibold">Discover</span> */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 animate-fade-in delay-400 flex flex-col items-center opacity-70">
            <span className="font-label-sm text-[10px] text-paper-cream tracking-widest mb-2 uppercase font-semibold">Scroll</span>
            <span className="material-symbols-outlined text-paper-cream animate-bounce">arrow_downward</span>
          </div>
        </section>

        {/* ===== TEA CEREMONY SECTION ===== */}
        {/* Original: <section class="py-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto bg-paper-cream"> */}
        <section className="py-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto bg-paper-cream">
          <div className="max-w-4xl mx-auto flex flex-col items-center">
            {/* Original: <div class="relative w-full aspect-[2/3] md:aspect-auto md:h-[800px] overflow-hidden rounded-lg shadow-xl mb-8 group"> */}
            <div className="relative w-full aspect-[2/3] md:aspect-auto md:h-[800px] overflow-hidden rounded-lg shadow-xl mb-8 group">
              <img
                alt="The Tea Ceremony"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                src={teaImg}
              />
            </div>
            <div className="text-center">
              {/* Original: <span class="font-label-sm text-label-sm text-cinematic-gold tracking-[0.2em] uppercase block mb-2 font-semibold">The Tradition</span> */}
              <span className="font-label-sm text-label-sm leading-label-sm text-cinematic-gold tracking-[0.2em] uppercase block mb-2 font-semibold">{teaCeremonySubtitle}</span>
              {/* Original: <h3 class="font-display-hero text-headline-lg-mobile md:text-headline-lg text-charcoal-ink">The Tea Ceremony</h3> */}
              <h3 className="font-display-hero text-headline-lg-mobile leading-headline-lg-mobile md:text-headline-lg md:leading-headline-lg font-semibold text-charcoal-ink">{teaCeremonyTitle}</h3>
            </div>
          </div>
        </section>

        {/* ===== NARRATIVE SECTION ===== */}
        {/* Original: <section class="py-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto bg-paper-cream"> */}
        <section className="py-section-gap px-4 md:px-canvas-margin max-w-[1440px] mx-auto bg-paper-cream">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            {/* Original: <span class="font-label-sm text-label-sm text-cinematic-gold tracking-[0.2em] uppercase block font-semibold">The Prelude</span> */}
            <span className="font-label-sm text-label-sm leading-label-sm text-cinematic-gold tracking-[0.2em] uppercase block font-semibold">{narrativeSubtitle}</span>
            {/* Original: <h3 class="font-display-hero text-headline-lg-mobile md:text-headline-lg text-charcoal-ink">Our Story Begins Here</h3> */}
            <h3 className="font-display-hero text-headline-lg-mobile leading-headline-lg-mobile md:text-headline-lg md:leading-headline-lg font-semibold text-charcoal-ink">{narrativeTitle}</h3>
            {/* Original: <p class="font-body-md text-body-md text-charcoal-ink/80 leading-relaxed"> */}
            <p className="font-body-md text-body-md text-charcoal-ink/80 leading-relaxed">
              {narrativeContent}
            </p>
          </div>
        </section>
      </main>

      {/* ===== FLOATING ACTION BUTTON ===== */}
      {/* Original: <div class="fixed bottom-24 right-6 md:bottom-12 md:right-12 z-[55] transition-transform duration-300 transform translate-y-20 opacity-0" id="fab"> */}
      {/* Original:   <button class="bg-charcoal-ink text-paper-cream w-16 h-16 rounded-full shadow-[0_8px_30px_rgba(26,26,26,0.12)] flex items-center justify-center hover:scale-105 active:scale-95 transition-all border border-cinematic-gold/30"> */}
      <div
        className={`fixed bottom-24 right-6 md:bottom-12 md:right-12 z-[55] transition-transform duration-300 ${
          showFab ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
        }`}
      >
        <button
          onClick={() => setSection('rsvp')}
          className="bg-charcoal-ink text-paper-cream w-16 h-16 rounded-full shadow-[0_8px_30px_rgba(26,26,26,0.12)] flex items-center justify-center hover:scale-105 active:scale-95 transition-all border border-cinematic-gold/30"
        >
          <span className="material-symbols-outlined">edit_calendar</span>
        </button>
      </div>
    </>
  );
}