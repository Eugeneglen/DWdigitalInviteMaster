'use client';

import { useEffect, useState } from 'react';
import { Building2, CalendarCheck, Users, Activity } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { useCMSStore } from '@/store/useCMSStore';
import { formatDistanceToNow } from 'date-fns';

interface StatsData {
  totalTenants: number;
  activeTenants: number;
  totalUsers: number;
  recentLogCount: number;
}

interface AuditLogItem {
  id: string;
  action: string;
  resource?: string;
  createdAt: string;
  user: { name: string };
}

function StatCard({
  icon: Icon,
  label,
  value,
  subValue,
  loading,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  subValue?: string;
  loading?: boolean;
}) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500 font-medium">{label}</p>
          {loading ? (
            <Skeleton className="h-8 w-20 mt-2" />
          ) : (
            <p className="text-2xl font-semibold text-charcoal-ink mt-1">{value}</p>
          )}
          {subValue && (
            <p className="text-xs text-gray-400 mt-1">{subValue}</p>
          )}
        </div>
        <div className="h-11 w-11 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
          <Icon className="h-5 w-5 text-gray-600" />
        </div>
      </div>
    </div>
  );
}

export default function CMSDashboard() {
  const authUser = useCMSStore((s) => s.authUser);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [recentLogs, setRecentLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const headers = {
          Authorization: `Bearer ${authUser?.token}`,
        };

        const [statsRes, logsRes] = await Promise.all([
          fetch('/api/cms/stats', { headers }),
          fetch('/api/cms/audit?limit=10', { headers }),
        ]);

        if (statsRes.ok) {
          const statsData = await statsRes.json();
          if (statsData.success) setStats(statsData.data);
        }

        if (logsRes.ok) {
          const logsData = await logsRes.json();
          if (logsData.success) setRecentLogs(logsData.data.logs);
        }
      } catch {
        // Silently handle errors
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [authUser?.token]);

  const getActionColor = (action: string) => {
    if (action.includes('create')) return 'bg-green-50 text-green-700 border-green-200';
    if (action.includes('update') || action.includes('toggle')) return 'bg-amber-50 text-amber-700 border-amber-200';
    if (action.includes('delete')) return 'bg-red-50 text-red-700 border-red-200';
    return 'bg-gray-50 text-gray-700 border-gray-200';
  };

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-xl font-semibold text-charcoal-ink">
          Welcome back, {authUser?.name?.split(' ')[0] || 'Admin'}
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Here&apos;s an overview of your platform.
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          icon={Building2}
          label="Total Tenants"
          value={stats?.totalTenants ?? '—'}
          subValue={stats ? `${stats.activeTenants} active` : undefined}
          loading={loading}
        />
        <StatCard
          icon={CalendarCheck}
          label="Active Events"
          value={stats?.activeTenants ?? '—'}
          loading={loading}
        />
        <StatCard
          icon={Users}
          label="Total Users"
          value={stats?.totalUsers ?? '—'}
          loading={loading}
        />
        <StatCard
          icon={Activity}
          label="System Health"
          value="Operational"
          loading={loading}
        />
      </div>

      {/* System Health Badge in the 4th card */}
      {/* (integrated above) */}

      {/* Recent Activity */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-semibold text-charcoal-ink">Recent Activity</h2>
        </div>

        <div className="divide-y divide-gray-100">
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="px-5 py-3.5 flex items-center gap-4">
                <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-48" />
                  <Skeleton className="h-3 w-32" />
                </div>
                <Skeleton className="h-3 w-20" />
              </div>
            ))
          ) : recentLogs.length === 0 ? (
            <div className="px-5 py-8 text-center text-sm text-gray-400">
              No recent activity to display.
            </div>
          ) : (
            recentLogs.map((log) => (
              <div
                key={log.id}
                className="px-5 py-3.5 flex items-center gap-4 hover:bg-gray-50/50 transition-colors"
              >
                <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                  <Activity className="h-3.5 w-3.5 text-gray-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-charcoal-ink">
                      {log.user?.name || 'Unknown'}
                    </span>
                    <Badge
                      variant="outline"
                      className={`text-[10px] px-1.5 py-0 font-mono ${getActionColor(log.action)}`}
                    >
                      {log.action}
                    </Badge>
                    {log.resource && (
                      <span className="text-xs text-gray-400">{log.resource}</span>
                    )}
                  </div>
                </div>
                <span className="text-xs text-gray-400 flex-shrink-0">
                  {log.createdAt
                    ? formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })
                    : '—'}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}