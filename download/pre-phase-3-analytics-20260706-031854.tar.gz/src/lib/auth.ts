import crypto from 'crypto';
import { SignJWT, jwtVerify } from 'jose';

// ============================================
// PASSWORD HASHING (Node.js scrypt — no external deps)
// ============================================

const SCRYPT_KEYLEN = 64;
const SCRYPT_COST = 16384; // N
const SCRYPT_BLOCK_SIZE = 8; // r
const SCRYPT_PARALLELISM = 1; // p

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16).toString('hex');
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEYLEN, { N: SCRYPT_COST, r: SCRYPT_BLOCK_SIZE, p: SCRYPT_PARALLELISM }, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${salt}:${derivedKey.toString('hex')}`);
    });
  });
}

export async function verifyPassword(password: string, hashed: string): Promise<boolean> {
  const [salt, key] = hashed.split(':');
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEYLEN, { N: SCRYPT_COST, r: SCRYPT_BLOCK_SIZE, p: SCRYPT_PARALLELISM }, (err, derivedKey) => {
      if (err) reject(err);
      resolve(derivedKey.toString('hex') === key);
    });
  });
}

// ============================================
// JWT TOKENS (jose — edge-compatible)
// ============================================

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'dw-digital-invite-dev-secret-change-in-production'
);

const JWT_EXPIRY = '8h';

export interface JWTPayload {
  userId: string;
  email: string;
  name: string;
  role: string; // master_admin | tenant_admin | editor | viewer
  tenantId?: string;
  tenantRole?: string;
}

export async function signToken(payload: JWTPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(JWT_EXPIRY)
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<JWTPayload> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as JWTPayload;
  } catch {
    return null as unknown as JWTPayload;
  }
}

// ============================================
// AUTH MIDDLEWARE HELPERS
// ============================================

export function extractBearerToken(request: Request): string | null {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) return null;
  return authHeader.slice(7);
}

export function getIpAddress(request: Request): string {
  return request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
    || request.headers.get('x-real-ip')
    || 'unknown';
}

export function getUserAgent(request: Request): string {
  return request.headers.get('user-agent') || 'unknown';
}

// ============================================
// ROLE CONSTANTS
// ============================================

export const ROLES = {
  MASTER_ADMIN: 'master_admin',
  TENANT_ADMIN: 'tenant_admin',
  EDITOR: 'editor',
  VIEWER: 'viewer',
} as const;

export type Role = (typeof ROLES)[keyof typeof ROLES];

export const ROLE_LABELS: Record<Role, string> = {
  master_admin: 'Master Admin',
  tenant_admin: 'Tenant Admin',
  editor: 'Editor',
  viewer: 'Viewer',
};

export const TENANT_ROLES = {
  ADMIN: 'admin',
  EDITOR: 'editor',
  VIEWER: 'viewer',
} as const;

export type TenantRole = (typeof TENANT_ROLES)[keyof typeof TENANT_ROLES];

export const TENANT_ROLE_LABELS: Record<TenantRole, string> = {
  admin: 'Admin',
  editor: 'Editor',
  viewer: 'Viewer',
};

// ============================================
// FEATURE KEY CONSTANTS
// ============================================

export const FEATURE_KEYS = {
  RSVP: 'rsvp',
  WISHES: 'wishes',
  STORY: 'story',
  MOMENTS: 'moments',
  SCHEDULE: 'schedule',
  QA: 'qa',
  GETTING_THERE: 'getting-there',
} as const;

export const FEATURE_LABELS: Record<string, string> = {
  rsvp: 'RSVP Form',
  wishes: 'Wishes & Blessings',
  story: 'Our Story',
  moments: 'Photo Moments',
  schedule: 'Event Schedule',
  qa: 'Q&A',
  'getting-there': 'Getting There',
};

export const GLOBAL_FEATURE_KEYS = {
  MULTI_TENANT: 'multi_tenant',
  CUSTOM_DOMAINS: 'custom_domains',
  ANALYTICS: 'analytics',
  NOTIFICATIONS: 'notifications',
  THEMING: 'theming',
} as const;

export const GLOBAL_FEATURE_LABELS: Record<string, string> = {
  multi_tenant: 'Multi-Tenant Support',
  custom_domains: 'Custom Domains',
  analytics: 'Analytics Dashboard',
  notifications: 'Notification Engine',
  theming: 'Advanced Theming',
};