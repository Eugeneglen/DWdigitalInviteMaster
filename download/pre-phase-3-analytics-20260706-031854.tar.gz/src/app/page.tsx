'use client';

import { useEffect, useSyncExternalStore } from 'react';
import { useNavigationStore } from '@/store/useNavigationStore';
import { useCMSStore, hydrateAuthFromStorage } from '@/store/useCMSStore';
import Header from '@/components/wedding/Header';
import MobileDrawer from '@/components/wedding/MobileDrawer';
import BottomNav from '@/components/wedding/BottomNav';
import Footer from '@/components/wedding/Footer';
import HomePage from '@/components/wedding/pages/HomePage';
import SchedulePage from '@/components/wedding/pages/SchedulePage';
import RSVPPage from '@/components/wedding/pages/RSVPPage';
import GettingTherePage from '@/components/wedding/pages/GettingTherePage';
import StoryPage from '@/components/wedding/pages/StoryPage';
import MomentsPage from '@/components/wedding/pages/MomentsPage';
import WishesPage from '@/components/wedding/pages/WishesPage';
import QAPage from '@/components/wedding/pages/QAPage';
import CMSLogin from '@/components/cms/CMSLogin';
import CMSLayout from '@/components/cms/CMSLayout';
import type { Section } from '@/store/useNavigationStore';

const GUEST_PAGES: Record<Section, React.ComponentType> = {
  home: HomePage,
  schedule: SchedulePage,
  rsvp: RSVPPage,
  'getting-there': GettingTherePage,
  story: StoryPage,
  moments: MomentsPage,
  wishes: WishesPage,
  qa: QAPage,
};

// useSyncExternalStore to detect client-side hydration (false on server, true on client)
const emptySubscribe = () => () => {};
function useHydrated() {
  return useSyncExternalStore(emptySubscribe, () => true, () => false);
}

export default function Home() {
  const { currentSection } = useNavigationStore();
  const { appMode, cmsPage, authUser, setAuthUser, setAuthLoading } = useCMSStore();
  const hydrated = useHydrated();

  const navigateToCMS = useCMSStore((s) => s.navigateToCMS);

  // Hydrate auth from localStorage on mount + check ?admin=true
  useEffect(() => {
    const stored = hydrateAuthFromStorage();
    if (stored) {
      setAuthUser(stored);
    }
    setAuthLoading(false);

    // Support ?admin=true URL parameter to enter CMS mode
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true') {
      navigateToCMS(stored ? undefined : 'login');
    }
  }, [setAuthUser, setAuthLoading, navigateToCMS]);

  // Don't render until hydrated to avoid flash
  if (!hydrated) {
    return (
      <div className="min-h-screen bg-paper-cream flex items-center justify-center">
        <div className="h-6 w-6 border-2 border-cinematic-gold border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // CMS Login
  if (appMode === 'cms' && (!authUser || cmsPage === 'login')) {
    return <CMSLogin />;
  }

  // CMS Layout (authenticated)
  if (appMode === 'cms' && authUser) {
    return <CMSLayout />;
  }

  // Guest mode
  const PageComponent = GUEST_PAGES[currentSection] || HomePage;

  return (
    <div className="min-h-screen flex flex-col bg-paper-cream text-charcoal-ink overflow-x-hidden selection:bg-cinematic-gold selection:text-paper-cream">
      <Header />
      <MobileDrawer />

      <div className="flex-1">
        <PageComponent key={currentSection} />
      </div>

      <Footer />
      <BottomNav />
    </div>
  );
}