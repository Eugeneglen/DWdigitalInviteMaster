import { NextRequest } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { verifyPassword, signToken, ROLES } from '@/lib/auth';

const loginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsed = loginSchema.safeParse(body);

    if (!parsed.success) {
      return Response.json(
        { success: false, error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const { email, password } = parsed.data;

    const user = await db.user.findUnique({
      where: { email },
      include: {
        tenantUsers: {
          include: { tenant: true },
        },
      },
    });

    if (!user) {
      return Response.json(
        { success: false, error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    const valid = await verifyPassword(password, user.password);
    if (!valid) {
      return Response.json(
        { success: false, error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    // Determine role
    let role = ROLES.MASTER_ADMIN;
    let tenantId: string | undefined;
    let tenantRole: string | undefined;

    // Check if user has a tenant association with admin role
    const adminTenantUser = user.tenantUsers.find((tu) => tu.role === 'admin');
    if (adminTenantUser) {
      role = ROLES.TENANT_ADMIN;
      tenantId = adminTenantUser.tenantId;
      tenantRole = adminTenantUser.role;
    } else if (user.tenantUsers.length > 0) {
      const firstTenant = user.tenantUsers[0];
      role = firstTenant.role === 'editor' ? ROLES.EDITOR : ROLES.VIEWER;
      tenantId = firstTenant.tenantId;
      tenantRole = firstTenant.role;
    }

    const payload = {
      userId: user.id,
      email: user.email,
      name: user.name,
      role,
      tenantId,
      tenantRole,
    };

    const token = await signToken(payload);

    return Response.json({
      success: true,
      user: payload,
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    return Response.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}