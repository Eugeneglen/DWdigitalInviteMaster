import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;

    const tenant = await db.tenant.findUnique({
      where: { slug, status: 'active' },
      include: {
        scheduleItems: {
          where: { enabled: true },
          orderBy: { order: 'asc' },
        },
        faqItems: {
          where: { enabled: true },
          orderBy: { order: 'asc' },
        },
        mediaItems: {
          orderBy: { order: 'asc' },
        },
        contentBlocks: {
          where: { status: 'published' },
          orderBy: { order: 'asc' },
        },
        featureToggles: true,
      },
    });

    if (!tenant) {
      return Response.json({ success: false, error: 'Not found' }, { status: 404 });
    }

    // Group media by category
    const media: Record<string, { url: string; alt: string | null; caption: string | null; isCover: boolean; order: number }[]> = {};
    for (const item of tenant.mediaItems) {
      const cat = item.category;
      if (!media[cat]) media[cat] = [];
      media[cat].push({
        url: item.url,
        alt: item.alt,
        caption: item.caption,
        isCover: item.isCover,
        order: item.order,
      });
    }

    // Group content blocks by sectionKey
    const contentBlocks: Record<string, { id: string; title: string | null; content: string | null; imageUrl: string | null; order: number; status: string }[]> = {};
    for (const block of tenant.contentBlocks) {
      const key = block.sectionKey;
      if (!contentBlocks[key]) contentBlocks[key] = [];
      contentBlocks[key].push({
        id: block.id,
        title: block.title,
        content: block.content,
        imageUrl: block.imageUrl,
        order: block.order,
        status: block.status,
      });
    }

    // Build features map
    const features: Record<string, boolean> = {};
    for (const ft of tenant.featureToggles) {
      features[ft.featureKey] = ft.enabled;
    }

    // Parse settings JSON
    let settings: Record<string, unknown> = {};
    try {
      settings = JSON.parse(tenant.settings);
    } catch {
      settings = {};
    }

    return Response.json({
      success: true,
      data: {
        tenant: {
          id: tenant.id,
          name: tenant.name,
          slug: tenant.slug,
          coupleName1: tenant.coupleName1,
          coupleName2: tenant.coupleName2,
          eventDate: tenant.eventDate?.toISOString() ?? null,
          venue: tenant.venue,
          settings,
        },
        schedule: tenant.scheduleItems.map((s) => ({
          id: s.id,
          time: s.time,
          title: s.title,
          description: s.description,
          tags: s.tags,
          order: s.order,
          enabled: s.enabled,
        })),
        faq: tenant.faqItems.map((f) => ({
          id: f.id,
          question: f.question,
          answer: f.answer,
          order: f.order,
        })),
        media,
        contentBlocks,
        features,
      },
    });
  } catch (err) {
    console.error('Content API error:', err);
    return Response.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}