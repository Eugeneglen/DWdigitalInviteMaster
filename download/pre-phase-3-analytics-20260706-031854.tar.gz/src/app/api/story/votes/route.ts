import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    // Get aggregated vote counts per destination
    const voteCounts = await db.honeymoonVote.groupBy({
      by: ['destination'],
      _count: { destination: true },
      orderBy: { _count: { destination: 'desc' } },
    });

    const destinations = voteCounts.map((v) => ({
      name: v.destination,
      votes: v._count.destination,
    }));

    // Get all suggestions
    const suggestions = await db.honeymoonSuggestion.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        name: true,
        suggestedBy: true,
        createdAt: true,
      },
    });

    return NextResponse.json({ destinations, suggestions });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}