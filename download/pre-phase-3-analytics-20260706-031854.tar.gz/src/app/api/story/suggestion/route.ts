import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';

const suggestionSchema = z.object({
  name: z.string().min(1, 'Suggestion is required'),
  suggestedBy: z.string().min(1, 'Your name is required'),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = suggestionSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { name, suggestedBy } = parsed.data;

    const suggestion = await db.honeymoonSuggestion.create({
      data: { name, suggestedBy },
    });

    return NextResponse.json({ success: true, id: suggestion.id });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}