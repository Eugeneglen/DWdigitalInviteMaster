import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const db = new PrismaClient();
const SCRYPT_KEYLEN = 64;

async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16).toString('hex');
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEYLEN, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${salt}:${derivedKey.toString('hex')}`);
    });
  });
}

async function seed() {
  console.log('🌱 Seeding database...');

  // ============================================
  // 1. USERS
  // ============================================
  const masterPassword = await hashPassword('Admin@2024');
  const masterAdmin = await db.user.upsert({
    where: { email: 'admin@dreamweavers.sg' },
    update: {},
    create: { email: 'admin@dreamweavers.sg', password: masterPassword, name: 'Dreamweavers Admin' },
  });
  console.log(`✅ Master admin: ${masterAdmin.email}`);

  const couplePassword = await hashPassword('Couple@2024');
  const coupleAdmin = await db.user.upsert({
    where: { email: 'eleanor@wedding.com' },
    update: {},
    create: { email: 'eleanor@wedding.com', password: couplePassword, name: 'Eleanor' },
  });

  // ============================================
  // 2. TENANT with full content settings
  // ============================================
  const tenantSettings = {
    theme: { primaryColor: '#C5A059', backgroundColor: '#FCF9F2', textColor: '#1A1A1A' },
    hero: {
      coupleName1: 'Eleanor',
      coupleName2: 'James',
      date: '2027-12-25T16:00:00+08:00',
      dateDisplay: 'December 25, 2027',
      tagline: 'Together with their families, request the pleasure of your company',
      teaCeremonyTitle: 'The Tea Ceremony',
      teaCeremonySubtitle: 'The Tradition',
      narrativeTitle: 'Our Story Begins Here',
      narrativeSubtitle: 'The Prelude',
      narrativeContent: 'Every great romance is a narrative woven over time. Ours began with a serendipitous meeting and has evolved into a tapestry of shared adventures, quiet moments, and a profound commitment to one another.',
    },
    venue: {
      name: 'The Singapore EDITION',
      shortName: 'The Singapore EDITION, Orchard',
      address: '38 Cuscaden Road, Singapore 249731',
      fullAddress: 'The Singapore EDITION, 38 Cuscaden Road, Singapore 249731',
      description: 'Nestled in the heart of Orchard Road, The Singapore EDITION is a luxury boutique hotel blending timeless elegance with modern sophistication. Its intimate event spaces and bespoke service make it the perfect setting for an unforgettable celebration.',
      mapEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.4!2d103.83!3d1.306!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1',
    },
    contact: { email: 'concierge@dreamweavers.events' },
    countdown: { enabled: true, targetDate: '2027-12-25T16:00:00+08:00' },
  };

  const tenant = await db.tenant.upsert({
    where: { slug: 'eleanor-james' },
    update: { settings: JSON.stringify(tenantSettings) },
    create: {
      name: 'Eleanor & James Wedding',
      slug: 'eleanor-james',
      eventType: 'wedding',
      status: 'active',
      coupleName1: 'Eleanor',
      coupleName2: 'James',
      eventDate: new Date('2027-12-25T10:00:00+08:00'),
      venue: 'The Singapore EDITION, 38 Cuscaden Road, Singapore 249731',
      settings: JSON.stringify(tenantSettings),
    },
  });
  console.log(`✅ Tenant: ${tenant.name}`);

  // Link couple admin
  await db.tenantUser.upsert({
    where: { userId_tenantId: { userId: coupleAdmin.id, tenantId: tenant.id } },
    update: {},
    create: { userId: coupleAdmin.id, tenantId: tenant.id, role: 'admin' },
  });

  // ============================================
  // 3. FEATURE TOGGLES
  // ============================================
  const features = ['rsvp','wishes','story','moments','schedule','qa','getting-there'].map(f => ({ featureKey: f, enabled: true, config: '{}' }));
  for (const f of features) {
    await db.tenantFeatureToggle.upsert({
      where: { tenantId_featureKey: { tenantId: tenant.id, featureKey: f.featureKey } },
      update: {}, create: { tenantId: tenant.id, ...f },
    });
  }
  const globalFeatures = [
    { featureKey: 'multi_tenant', enabled: true, description: 'Enable multi-tenant account management' },
    { featureKey: 'analytics', enabled: true, description: 'Enable analytics dashboard for tenants' },
    { featureKey: 'notifications', enabled: false, description: 'Enable notification engine (email/SMS)' },
    { featureKey: 'custom_domains', enabled: false, description: 'Enable custom domain mapping' },
    { featureKey: 'theming', enabled: true, description: 'Enable advanced theme customization' },
  ];
  for (const f of globalFeatures) {
    await db.globalFeatureToggle.upsert({ where: { featureKey: f.featureKey }, update: {}, create: f });
  }

  // ============================================
  // 4. SCHEDULE ITEMS
  // ============================================
  const scheduleItems = [
    { time: '4:00 PM', title: 'The Ceremony', description: 'Join us as we exchange our vows and start our new chapter together.', tags: JSON.stringify(['Formal Attire']), order: 0 },
    { time: '5:30 PM', title: 'Cocktail Hour', description: 'Enjoy signature drinks and light hors d\'oeuvres in the garden courtyard.', tags: '[]', order: 1 },
    { time: '7:00 PM', title: 'Dinner & Dancing', description: 'A seated dinner followed by a night of celebration, music, and joy on the dance floor.', tags: '[]', order: 2 },
  ];
  for (const item of scheduleItems) {
    await db.scheduleItem.upsert({
      where: { id: `${tenant.id}-schedule-${item.order}` },
      update: {},
      create: { id: `${tenant.id}-schedule-${item.order}`, tenantId: tenant.id, ...item },
    });
  }
  console.log(`✅ ${scheduleItems.length} schedule items seeded`);

  // ============================================
  // 5. FAQ ITEMS
  // ============================================
  const faqItems = [
    { question: 'What is the dress code for the evening reception?', answer: 'The evening calls for Black Tie Optional. We encourage our guests to embrace the elegance of the venue. For gentlemen, a dark suit or tuxedo is appropriate. For ladies, floor-length gowns or sophisticated cocktail attire is preferred.', order: 0 },
    { question: 'Is transportation provided to the venue?', answer: 'Yes. For guests staying at our recommended hotels, dedicated luxury shuttles will depart from the main lobbies at exactly 4:15 PM on Saturday. Return transport will run every thirty minutes from 11:00 PM onwards.', order: 1 },
    { question: 'Are children invited to the celebration?', answer: "While we adore the little ones in our lives, our wedding weekend will be an adult-only affair (18+), allowing everyone to relax and fully immerse themselves in the evening's festivities.", order: 2 },
    { question: 'How should I inform you of dietary requirements?', answer: 'Our culinary team is prepared to accommodate all medical and ethical dietary restrictions. You will be prompted to detail any specific allergies or preferences when completing the formal RSVP process.', order: 3 },
  ];
  for (const item of faqItems) {
    await db.fAQItem.upsert({
      where: { id: `${tenant.id}-faq-${item.order}` },
      update: {},
      create: { id: `${tenant.id}-faq-${item.order}`, tenantId: tenant.id, ...item },
    });
  }
  console.log(`✅ ${faqItems.length} FAQ items seeded`);

  // ============================================
  // 6. MEDIA ITEMS (gallery images)
  // ============================================
  const mediaItems = [
    { category: 'hero', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBeAe38AA5-0h4B5MmgQCqv54oQXyPMGznDKaw2sJI_FnTbB_yXXWOpirFlFycj_2VI02IVLouUTt86Y1J7Ls-bRsMOHPAcfSqruVoh87sfhw3vi2Z6t1C7ogCLtkvF6QbJkwuV0av8pXTrUeAAi6ymnZpvyOr8qVjTNNorAOmqRrW_fohX_xlkscmBh39K4Wtvs6TH0Nvb_X3LQQRD9W_sySN_iWbWw9O0au8u1jO-hSekE9pSGNo5zsTz3o9PWy5xbzc6lq3knkIy', alt: 'Wedding Hero Portrait', caption: null, order: 0, isCover: true },
    { category: 'hero', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA-OyKfcsxXAmZDArHbDXl1cVCgGUG5liFPzyHdVvMG6_4jN9pNTrN9GCrkdnegli9UPJUSPs39KJRsRP7AiLem4xYS-q1ZYq1T3DAIqyvn3wAvbdkoMVkufft0SpQw4gDTPSnIml6k62lRYobUrNu70UGIILiMZQ0fAydTXXwVZ1oswQZ-mjPT8H9mDDqfhxsMSI5zla8GKz_ILXbmdRjtRUk682dPEDBD6I81DzEx7dITgjb6vxQoee5599jkYf_vCYP7npydvxqx', alt: 'Banner Background', caption: null, order: 1 },
    { category: 'tea-ceremony', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA6SiJt49KQCmMAhF-X_tmX1Y1NKhTieT6ApO53PD9gYuvLO0e78WTxzg8BV7Wnhe6oJ6sG4SwJ4U-nH2m33dv7I89IhLgrHDkabts7ws-QwPlv-ycUzhyuBN0c04ka2inAyysumlM1w-sR8stBZ51HJOGZkQO6cAtfrn9RXWZRFlHJlUp8Jqzi-nBu3xGs57xm7L2Le06Put3xBDMAe39zkMMsdcuUkbeyw5c4Q6VxvXkSmMbcpLM-HJK1iMgYVLkn2kzqUPEALYpH', alt: 'The Tea Ceremony', caption: 'The Tea Ceremony', order: 0, isCover: true },
    { category: 'venue', url: 'https://sfile.chatglm.cn/images-ppt/4adf4afbb9a2.jpg', alt: 'The Singapore EDITION — Wedding Venue', caption: 'Wedding Venue', order: 0, isCover: true },
    { category: 'schedule', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAsLNSEjy771owdkkDbKTl1nE5oEzBQFVHob_HKiQb9eJb1X7I79-CxGjCPeKwCSHhwswJRqSrt3ox_aktMQUGlyzg6Eoo5R0aH6CYxxKj5f3uZCWdaDfZEIqmxwZd5DgdvCUWZfIdnNvixcYvcspOOFnGM2ThX9BPZz-ftetacA-b6CkxEEp9BdSatnTG55-e8tZz1jlG1euZgtw17iI67tcMGtR2azzCg8GvNH-xQPfUJlAXxGC3jU9Q7dbVZPK-xnHwtTl5eRNknueI', alt: 'The Ceremony', caption: 'The Ceremony', order: 0 },
    { category: 'schedule', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC01POr_eFI2RUG86kAb7dHs-q12Kj6HzxEoXpnzTnJ9n_VB9_BJL6Iy8vtGixOWTn1jVNZKDjXNQkHSy9Gsa8KI5IomZe3968VCNWHhXNZ44gbgs5LCBp4_Axjbj72RJwN0BWAIEmrqH8lgR-_j2_9Ci79wI4t583OCS4YuDca-s2xldrzBhBM-KeS4GFVFDSQdzWRY-4chmwkFfFgO3g-S4VS_jae416SCd-357i_ix3m68zwnHtpBSxyXFSjZISZ_Z66Jlxj6Npv_Lo', alt: 'The Celebration', caption: 'The Celebration', order: 1 },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAm-8WDgkq_3PeNjdM4_SPcbdyPc4j1BN1NYWpstlUalLgRDkOi-VrJG2ZcdDt04YwBhlSegxOEQ4dbw-6zr2xKHQeTO5gJe67RlcYJ2IkUn3Dp8ZbTzfL8aD2Tq8rbse4QsZBGuz1fOPmW42rjorV-F8aY14aRHg_wk_TAMAaeqaBllL8Qpx_POk9EP9b5wjS_YXtMBnKH7-nGAPwIbuNCwetnkUm6A1gonIw4KTEsPRqq2sW_1A3jAX6wnSIeZTPdzM3VYkva56VG', alt: 'Early Years', caption: 'Early Years', order: 0, isCover: false },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAaySYsDYGyX6N9CoV24yS9bjuLYqQWIJwG8qS2qCMj2do69ncL22s286MrboC8HGtgl1tP6_JTj85seIO4TolelvHDIqTInWBTwFyuk_MJZN0a5w6P0QX4AQUVLx2oCOPDelyGCdOmRviKG1bD4nqPr3zkgUKWgXNmnGP5a0b4U2k-nDG2Hl_lDM2moRehiYXKnwB872KgPkaI7Br6uq1DHIKKb34AY9ybXoB9pT-x3W5PKHguLL3DaI6VsnfHWT18OAeoVAgwQsvH', alt: 'College Days', caption: 'College Days', order: 1, isCover: false },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCSIFjFy2YecMgyEcWPUwcxc0x0aeave6t83lRrx9I562NRYIPDn8I7lAYE1hLalBtCsq22XBSUM5UIQ9O7SG4LZbJXDpn7Y8iUaVW7FNVdfMuTbn2uGLOQCl3MV6EgnxcpYOsswCptEyKegR8_YCSeNk438RKjHVC3xs4HkIvlq5kEe3f5OTdP36lsirovgw_07Ry4YwVm06xv8uZ5GmhrX-oU02i7OASDM7Gdr1UkxL2NiOdyce7PSAl_0UW-xZMxl1DFIStbWdaU', alt: 'First Summer', caption: 'First Summer', order: 2, isCover: false },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC8RAoFnH7L9tFmSjN3sfNRhKNcQZhi5ysusn41rPRCnxgkRdC7gmZSPZ0XoULR83j3q0uqgavwoBitCxAoF2KF-DzsGg34B0pCMslmkusZodhIipUFKpkQj-cr4FRMLcyDdy5SzxPsOAi7OKQa4uioJSi0KhKwePpXNmReV2WzTMoSRUP-wqNUrofcUas0L_WwXeNwan3c9CMIkxBHHWhkKwYOKyjXd51ixRMzL_X37bZqgP1DUhrpEUz27iNPB8XgvhtSDOiH4Pd2', alt: 'Where it Began', caption: 'Where it Began', order: 3, isCover: false },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAo_iwupchnJHvXMl5E17TFsoHJ23KgUb5kI8vnFt1NyIODCLIK9tSJ-5NmvdWcdS21fueeNi-8HX5FPWZ-rXZPyru8V-DUKsc_aEK6yGqTQyOAJubhxaZWj_07HSUyF0yvxVn5G5WmJtNxLq9EZh0X8EJ5Q_4ZMQ7HMh_FQqAIW6OofZZw4zhAhwyIOyrlVwaURh_XvFES7-3dVvxz2sJ0iTNmt9VV0roh3t83hM1Vam0FV-9y9b3d4c46RZVcBv84AwjC1tew60c7', alt: 'Academic Milestones', caption: 'Academic Milestones', order: 4, isCover: false },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA6yfZZlKuOgc7f9BoIGCAh3JLsOmPBPPzDUbciYvBGuEIyibR3sGWAMVAKm1otVVQWGI5yGzzdXPiiZbtmXiSvQY5Mk_ZQI-pJjKHbsc3qcwpp3mK6LwLmHQQyCZYIp1ELY6UEftahE-61i-LgWdRzahJMkrnhPI9bwahxFIRLxhjIoG9HE-FPNqZI_2KBnRoblo5SKLkW6SreAOLXOETB3qeo3ymZ6wtPqOZTBpRsIId11CRKbr1xaKqF1sqRtv0N5vQHlAWhlHqA', alt: 'Early Adventures', caption: 'Early Adventures', order: 5, isCover: false },
    { category: 'gallery', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCXe37633UXErQ8VKr_s7lNWN-MZNVGtupB_D1WmBY3PqnOFWIYr8BqlsYPPX-k-mJA8AbmrOauWIohhltVLnmMvLgbkjNALuIFpdEGRiKe3wDFCRt21tZvTIc3SMgCtoDnEBZOx7_HGu5RSa3uuFbCugmJpXpDg-QE9vxZG9QXDgqETu3c1_QmYtU8K41OyOTkwqFdFlYxdRj_WCCBTKgLSI4NchqgRYqQv4_xZQICoqEfBOB1aMyFqVS4OSA6-X7VuOvui4qjJnc_', alt: 'Social Circles', caption: 'Social Circles', order: 6, isCover: false },
    { category: 'story', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBZxkwieg-SjxgRYOZxJlQ1v05okmlTqzvosp-ANHaaCSQStncGv3ORTlPiE-uSYP7mQcE_wcB5Povhsm25x-eThbTLAYPt1XD-14RTSL9R5a1etGsU54CUWIwAK_4ckHoB-gD85mc-uqQwOckXVYmn0J7u0r6WkNQ2eFKKTBWBJ8yU_nirHHy8GC7vKRVnGPL6P_TymHuuKnjM3ERN9Zvho_5v7pICElncd6F8dHF-lVKppvz4kKyQe9je7CIDwOSBlcyxaGU6yY-D', alt: 'Our Story Hero', caption: null, order: 0, isCover: true },
    { category: 'story', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAQPSczTWgJLZS_vzNbN6wuPsTVw72YpOY0ldIaXb2nEM0DjbAoH__IyOfEvlXkIvif3k6TiVwdgbsAPvCUuustCXJ5ogM8o9Mf8qfnHNM052duEcCK8KPbJVfqn8sOuo9cpUPx6XWqHpBxvEfinvKzqiiI7zy3XkVYQ7w0ElfPw1kVlE-oTiwbdti2a6Q3pUBuogYx0KyKtviULD2olRj3ZTd29I37Yi80hUtQtS9LWTuKEtFJvAKUdLp2wmjdEM8om4Ku67LEDI4t', alt: 'Chapter 1', caption: null, order: 1 },
    { category: 'story', url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBzzvAxvGICtmDJ5Ase_8SKR0gvAAqXe_96pLSdSUEjYyVgenag3qekxDbjpLG_SXknWJEoOXPP_XcdU4WMSloZvzj9Pn-dxdG0BBlp0lglCSzzoxLL3-2CaKrawuVRqBglPiiimHDNTlMHai2pnrr404Xg8EgQq8tdW5qRhs-bx2k6N52M80DDUW27KtR0Nc4-WkNjwCsNX8XuiyHBZTqdhpBqml323YRMNj-0offH-_Sn3jp1yxw-EAZs939pzoyGzEfpRwsteoXv', alt: 'The Proposal', caption: null, order: 2 },
  ];
  for (const item of mediaItems) {
    await db.mediaItem.upsert({
      where: { id: `${tenant.id}-media-${item.category}-${item.order}` },
      update: {},
      create: { id: `${tenant.id}-media-${item.category}-${item.order}`, tenantId: tenant.id, ...item },
    });
  }
  console.log(`✅ ${mediaItems.length} media items seeded`);

  // ============================================
  // 7. CONTENT BLOCKS (story sections, directions)
  // ============================================
  const contentBlocks = [
    { sectionKey: 'story-chapter1', title: 'Where It All Began', content: 'It was a warm evening in September when Eleanor walked into that crowded café — the one with the mismatched chairs and the espresso machine that never stopped hissing. James was already there, nursing a cold latte and pretending to read. Their eyes met over the counter. She ordered a chamomile tea. He pretended not to notice. But he did.', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAQPSczTWgJLZS_vzNbN6wuPsTVw72YpOY0ldIaXb2nEM0DjbAoH__IyOfEvlXkIvif3k6TiVwdgbsAPvCUuustCXJ5ogM8o9Mf8qfnHNM052duEcCK8KPbJVfqn8sOuo9cpUPx6XWqHpBxvEfinvKzqiiI7zy3XkVYQ7w0ElfPw1kVlE-oTiwbdti2a6Q3pUBuogYx0KyKtviULD2olRj3ZTd29I37Yi80hUtQtS9LWTuKEtFJvAKUdLp2wmjdEM8om4Ku67LEDI4t', order: 0 },
    { sectionKey: 'story-proposal', title: 'The Proposal', content: 'After three years of adventures, late-night conversations, and building a life together, James planned the perfect proposal. A rooftop dinner under the stars, their favorite playlist in the background, and a question that changed everything. She said yes before he even finished asking.', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBzzvAxvGICtmDJ5Ase_8SKR0gvAAqXe_96pLSdSUEjYyVgenag3qekxDbjpLG_SXknWJEoOXPP_XcdU4WMSloZvzj9Pn-dxdG0BBlp0lglCSzzoxLL3-2CaKrawuVRqBglPiiimHDNTlMHai2pnrr404Xg8EgQq8tdW5qRhs-bx2k6N52M80DDUW27KtR0Nc4-WkNjwCsNX8XuiyHBZTqdhpBqml323YRMNj-0offH-_Sn3jp1yxw-EAZs939pzoyGzEfpRwsteoXv', order: 1 },
    { sectionKey: 'story-tidbit-1', title: 'Who said "I love you" first?', content: 'It was mutual, during a particularly chaotic road trip where we got hopelessly lost but completely enjoyed the detour.', order: 2 },
    { sectionKey: 'story-tidbit-2', title: 'Favorite shared hobby?', content: 'Collecting vintage records and spending Sunday mornings listening to them while attempting to perfect our French press technique.', order: 3 },
    { sectionKey: 'getting-there-car', title: null, content: 'From the city centre, head north on Orchard Road towards Tanglin. Turn left onto Cuscaden Road. The Singapore EDITION will be on your right. Complimentary valet parking is available for all wedding guests — simply state your name at the entrance.', order: 0 },
    { sectionKey: 'getting-there-transit', title: null, content: 'The nearest MRT station is Orchard (NS22), approximately a 10-minute walk via Orchard Boulevard. From the station, turn right onto Orchard Road, then left onto Cuscaden Road. The hotel entrance is visible from the main road.', order: 1 },
    { sectionKey: 'venue-description', title: null, content: 'Nestled in the heart of Orchard Road, The Singapore EDITION is a luxury boutique hotel blending timeless elegance with modern sophistication. Its intimate event spaces and bespoke service make it the perfect setting for an unforgettable celebration.', order: 0 },
  ];
  for (const block of contentBlocks) {
    await db.contentBlock.upsert({
      where: { id: `${tenant.id}-block-${block.sectionKey}` },
      update: {},
      create: { id: `${tenant.id}-block-${block.sectionKey}`, tenantId: tenant.id, ...block },
    });
  }
  console.log(`✅ ${contentBlocks.length} content blocks seeded`);

  console.log('\n🎉 Seed complete!');
  console.log('\n📋 Credentials:');
  console.log('  Master Admin: admin@dreamweavers.sg / Admin@2024');
  console.log('  Couple Admin: eleanor@wedding.com / Couple@2024');
  console.log(`\n📊 Content: ${scheduleItems.length} schedule, ${faqItems.length} FAQ, ${mediaItems.length} media, ${contentBlocks.length} blocks`);
}

seed()
  .catch((e) => { console.error('❌ Seed failed:', e); process.exit(1); })
  .finally(async () => { await db.$disconnect(); });