import { create } from 'zustand';

// ============================================
// APP MODE & CMS NAVIGATION TYPES
// ============================================

export type AppMode = 'guest' | 'cms';

export type CMSPage =
  | 'login'
  | 'dashboard'
  | 'tenants'
  | 'tenant-detail'
  | 'users'
  | 'features'
  | 'audit'
  | 'settings'
  | 'schedule-editor'
  | 'faq-editor'
  | 'media'
  | 'content'
  | 'rsvps'
  | 'wishes'
  | 'analytics';

// ============================================
// AUTH STATE TYPES
// ============================================

export interface AuthUser {
  userId: string;
  email: string;
  name: string;
  role: string; // master_admin | tenant_admin | editor | viewer
  tenantId?: string;
  tenantRole?: string;
  token: string;
}

// ============================================
// CMS STORE INTERFACE
// ============================================

interface CMSState {
  // App mode
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;

  // CMS navigation
  cmsPage: CMSPage;
  setCmsPage: (page: CMSPage) => void;
  selectedTenantId: string | null;
  setSelectedTenantId: (id: string | null) => void;

  // Auth
  authUser: AuthUser | null;
  setAuthUser: (user: AuthUser | null) => void;
  isAuthLoading: boolean;
  setAuthLoading: (loading: boolean) => void;

  // Sidebar
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;

  // Actions
  login: (user: AuthUser) => void;
  logout: () => void;
  navigateToCMS: (page?: CMSPage) => void;
  returnToGuest: () => void;
}

export const useCMSStore = create<CMSState>((set, get) => ({
  // Default to guest mode
  appMode: 'guest',
  setAppMode: (mode) => set({ appMode: mode }),

  // CMS page navigation
  cmsPage: 'dashboard',
  setCmsPage: (page) => {
    set({ cmsPage: page });
  },
  selectedTenantId: null,
  setSelectedTenantId: (id) => set({ selectedTenantId: id }),

  // Auth state
  authUser: null,
  setAuthUser: (user) => set({ authUser: user }),
  isAuthLoading: true,
  setAuthLoading: (loading) => set({ isAuthLoading: loading }),

  // Sidebar state
  sidebarOpen: true,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),

  // Actions
  login: (user) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('dw_auth_token', user.token);
      localStorage.setItem('dw_auth_user', JSON.stringify(user));
    }
    set({ authUser: user, appMode: 'cms', cmsPage: 'dashboard' });
  },

  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('dw_auth_token');
      localStorage.removeItem('dw_auth_user');
    }
    set({
      authUser: null,
      appMode: 'guest',
      cmsPage: 'dashboard',
      selectedTenantId: null,
    });
  },

  navigateToCMS: (page) => {
    set({ appMode: 'cms', cmsPage: page || 'dashboard' });
  },

  returnToGuest: () => {
    set({ appMode: 'guest', selectedTenantId: null });
  },
}));

// ============================================
// HYDRATION HELPER
// Call this once on app mount to restore auth from localStorage
// ============================================

export function hydrateAuthFromStorage(): AuthUser | null {
  if (typeof window === 'undefined') return null;

  const token = localStorage.getItem('dw_auth_token');
  const userJson = localStorage.getItem('dw_auth_user');

  if (token && userJson) {
    try {
      const user = JSON.parse(userJson) as AuthUser;
      return user;
    } catch {
      localStorage.removeItem('dw_auth_token');
      localStorage.removeItem('dw_auth_user');
    }
  }

  return null;
}