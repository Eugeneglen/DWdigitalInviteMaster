import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';

const contactSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  contact: z.string().optional(),
  reason: z.string().min(1, 'Reason for contact is required'),
});

async function getDefaultTenantId(): Promise<string> {
  const tenant = await db.tenant.findFirst({ where: { status: 'active' } });
  if (!tenant) throw new Error('No active tenant found');
  return tenant.id;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = contactSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { name, email, contact, reason } = parsed.data;
    const tenantId = await getDefaultTenantId();

    const submission = await db.contactSubmission.create({
      data: {
        tenantId,
        name,
        email,
        contact: contact || null,
        reason,
      },
    });

    return NextResponse.json({ success: true, id: submission.id });
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}